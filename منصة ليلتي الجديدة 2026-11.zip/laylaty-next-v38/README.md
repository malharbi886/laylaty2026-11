# Laylaty Next — development starter

Independent starter, **not a finished marketplace**. Read `AGENTS.md`, `CODEX_TASK.md`, `docs/REQUIREMENTS.md`, `docs/ARCHITECTURE.md`, and `docs/PHASE_REPORT.md`.

### Local smoke test
`php apps/api/tests/smoke.php`

### React web (after installing dependencies)
`cd apps/web && npm install && npm run dev`

### Laravel API
`apps/api/composer.json` describes intended dependencies; **Laravel is not installed or bootstrapped**. Codex should scaffold the actual framework safely in this independent folder and integrate existing domain classes. No migrations until explicitly authorized.


## الإصدار الرابع
راجع `docs/PHASE4.md` للتغييرات وموانع التشغيل الإنتاجي.

## Consolidated V9
See `docs/REMAINING_PHASES.md` for delivered modules, limitations, and production blockers.

V17 purchase receipt implementation: docs/PHASE17.md


## V32 security iteration
See `docs/PHASE32_TENANT_CONTEXT.md` and `docs/SECURITY_QUERY_INVENTORY_V32.json`. Security review remains incomplete.


## V34
Random public tenant identifiers, authenticated tenant membership discovery, and public-ID-only tenant route resolution. See docs/PHASE34_RANDOM_TENANT_IDENTIFIERS.md.
