# V35 — Seven-character public store identifiers

- Exactly **5 digits**, **1 uppercase English letter**, **1 lowercase English letter**, shuffled into unpredictable positions (e.g. `4a81B92`).
- Generated with cryptographically secure `random_int` and checked for exact structure.
- There are 10^5 × 26 × 26 × 42 = **2,839,200,000** possible strings (42 distinct positions for uppercase/lowercase). Collisions remain possible; database UNIQUE and retry-on-unique-violation are required.
- Fresh databases use migration `000018` with `VARCHAR(7) UNIQUE` and retry backfill.
- Existing V34 databases containing 24-character identifiers are **not automatically rewritten**. Migration `000019` blocks conversion until a reviewed alias/redirect plan protects existing URLs and API clients. Do not modify production IDs casually.
- IDs are **not secrets** and are not a substitute for authenticated tenant authorization.
- **No migrations were run**; Laravel/MySQL integration tests still required.
