# V21 — Cash POS completion (prototype)

- Completes a **draft** sale in an **open** shift with an internal cash receipt; no payment gateway integration.
- Checks frozen line totals, locks shift and branch, decrements product inventory and records movements atomically.
- Idempotent replay for already completed sales; shift closure reconciles completed sales against cash receipts.
- Hall tenants are blocked. No card sales, refunds, ZATCA, automatic journal posting, or verified real cash collection.
- IMPORTANT: Laravel/MySQL runtime, concurrency tests, accounting integration, inventory edge cases, and end-to-end tests remain unverified. Do not deploy to production.
- The route file had stray `use` statements before `<?php`; this was corrected.
