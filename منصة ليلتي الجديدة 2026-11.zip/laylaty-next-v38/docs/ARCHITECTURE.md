# Laylaty Next — architecture decision (initial)

- Independent modular monolith, Laravel API + React TypeScript SPA; MySQL planned.
- TenantContext is a domain-level safeguard, **not** a complete persistence security boundary. Laravel middleware, policies, query scopes, file and job scoping must be added before any production use.
- BookingPolicy is a domain illustration only. Production confirmation requires DB transactions and locking/uniqueness to prevent races.
- Accounting uses integer halalas; journal validation alone does not implement a ledger or immutable posting.
- Payments and ZATCA connections are not implemented. Never enable real money movement without audit and approvals.
- The UI is a static shell; authentication and APIs are not connected.
