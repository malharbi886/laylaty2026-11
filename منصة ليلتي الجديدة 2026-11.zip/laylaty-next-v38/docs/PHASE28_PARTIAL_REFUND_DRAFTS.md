# V28 — Partial refund draft persistence

Implemented: authenticated tenant-scoped draft endpoint, sale row locking, snapshot lines, idempotency-key uniqueness rejection, store-only permissions, validation and quote calculation.

**Not implemented:** issuing refunds, reserving refundable quantities, settlement of concurrent drafts, updating stock, ZATCA credit notes, payment gateway refunds or financial journals. Multiple drafts can quote the same quantity; they must NOT be interpreted as approved refunds. Do not deploy without integration and concurrency testing.

Endpoint: POST /api/tenants/{tenant}/store/pos/shifts/{shift}/sales/{sale}/partial-refund/drafts

Payload: request_key, reason, lines [{line_id, quantity}].
