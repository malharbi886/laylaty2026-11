# V5 — Laravel-ready API skeleton
## Added
- Tenant membership middleware requiring an authenticated user and scoped tenant route.
- Booking list/detail/create/confirm endpoints.
- Payment submission endpoint (pending only; **no payment verification or ledger posting**).
- Booking lookup indexes and compound tenant reference.
- Audit events for booking creation/confirmation and payment submission.

## Known gaps / mandatory before use
1. Laravel framework and Sanctum must be installed and configured; this is **not** a complete Laravel installation.
2. The initial migration must be reviewed before running; it contains project-specific assumptions.
3. Booking overlap currently locks the branch row to serialize creation within a branch; it does not model multiple halls per branch or configurable time slots. **Do not deploy this to real halls** before adding hall_id and booking allocation logic.
4. Creation and confirmation both lock branch rows; verify lock order, deadlock handling and availability under MySQL concurrency tests before production.
5. Payment submission is a manual record marked `pending`, not proof of actual payment. Implement verification/approval, idempotency, reversals, and double-entry posting before use.
6. Fine-grained RBAC, contracts, tax invoices, account ledgers, and tests against MySQL are pending.
7. Never run migrations on existing production databases without approval and backup validation.
