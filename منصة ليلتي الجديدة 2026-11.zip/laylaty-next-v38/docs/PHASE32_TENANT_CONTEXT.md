# V32 — Request-local tenant context and security review inventory

- Adds immutable request-local `TenantContext` to prevent cross-request tenant state leakage.
- Middleware checks membership and tenant type, then attaches the context to the request.
- Dashboard and store profile guard independently validate route tenant against authenticated context.
- Customer task listing is additionally constrained through the owning customer event.
- Adds unit tests for tenant mismatch, role/type denials and malformed identifiers.
- `scripts/security_inventory.py` produces a conservative list of controller query patterns for manual review; a finding is **not** proof of a vulnerability and a clean result is **not** proof of safety.

## Known blockers
- Other controllers still need request-context defense in depth and end-to-end IDOR tests.
- No actual Laravel installation, MySQL concurrency tests, or penetration test performed.
- File storage, exports, queues, cache, notifications, webhooks, subscription and accounting isolation remain release blockers.
- Do not run migrations or production payments without approval.
