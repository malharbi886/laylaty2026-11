# V33 — Tenant/customer isolation hardening

- Added pure `TenantScope` guards for resource tenant, branch tenant and customer owner IDs, with strict positive integer parsing and fail-closed mismatch rejection.
- Customer task creation now verifies event ownership **inside** a database transaction and locks the parent event row before inserting a task.
- Customer task status updates also lock the owning event row.
- Booking confirmation now refuses to continue when the tenant-scoped branch or hall record does not exist, rather than silently ignoring missing lock targets.
- Added V33 domain and structural regression tests. Existing tenant-scoped controller queries remain subject to manual review.

## Security caveats / release blockers

These are defense-in-depth fixes, **not** a proof of full tenant isolation. No Laravel integration suite, MySQL migrations, concurrency tests, file-storage security audit, webhook checks or penetration testing have been run. Do not deploy to production or accept real payments. All existing files are retained in a new independent copy.
