# V34 — Non-sequential tenant identifiers and login membership discovery

- Each store/hall gets a **24-character random uppercase hexadecimal** `public_id` (96-bit entropy), generated with PHP `random_bytes`. A database unique constraint prevents duplicate IDs; backfill retries collisions.
- The internal numeric `tenants.id` remains the private relational key; public tenant API paths use `public_id` only.
- After login with existing Sanctum authentication, `GET /api/my/tenants` lists only memberships belonging to the authenticated user, returning `public_id`, `name`, `type`, and `role` (no numeric tenant IDs).
- Middleware resolves public ID to internal tenant ID, checks membership and role, then passes trusted internal ID to existing controllers.
- **New tenants must receive a generated public_id in their creation service**, with a unique-violation retry; otherwise the NOT NULL constraint rejects creation. The existing project has no complete tenant-onboarding service.
- **Security**: random IDs are identifiers, NOT authentication tokens. Membership checks remain mandatory on every request; rate limits, audit logs, CSRF/session security, branch scopes, and object-level authorization still need integration tests.
- **Breaking API change**: legacy `/api/tenants/{numeric_id}/...` paths now return 404. Update React/app clients to use public IDs before deployment.
- Migration included but **NOT executed**. Verify on a cloned MySQL DB and plan downtime/rollback before applying.
- Tests cover ID format/uniqueness sampling only, NOT a formal proof of collision-free IDs or production isolation.
