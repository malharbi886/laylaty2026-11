# Laylaty | MY NIGHT — baseline requirements

## Products
1. Customer app/web: discover halls and specialty stores, events and task lists, budgets, bookings/orders, invoices, reviews and invitations.
2. Hall owner dashboard: branches/halls, images/360, Umm al-Qura Hijri and Gregorian calendar, slots, upcoming bookings, booking details, status change, deposits, contracts and annexes, optional accounting subscription; no POS.
3. Merchant dashboard: specialized storefront, products/services, orders/appointments, branches/employees, catalog, POS when applicable, accounting.
4. Central admin: tenant and specialty administration, subscriptions, hall booking commissions, content, disputes, reports, role permissions.

## Specialties (16)
1. قاعات وقصور الأفراح
2. تنظيم وتنسيق المناسبات
3. الكوش والديكور
4. الورود
5. التصوير والفيديو
6. فساتين الزفاف والسهرات
7. التجميل والمكياج
8. الحلويات والكيك
9. الضيافة والقهوة
10. البوفيهات والطعام
11. التوزيعات والهدايا
12. الدعوات والطباعة
13. تأجير مستلزمات المناسبات
14. الصوتيات والإضاءة
15. الترفيه والزفات
16. سيارات الزفاف والنقل

## Booking reference
Single immutable booking identifier links calendar, booking details, contract, annex, payment, invoice, ledger and reports. Clicking booking number from any module navigates to same details with appropriate tab, subject to authorization.

## Hall settings
Business data, logo, tax registration, address, bank info, branches, contract clauses/templates, annex templates, booking status colors, deposits/cancellation rules, staff roles and permissions.

## Accounting
Chart of accounts, double-entry journals, trial balance, general ledger, receivables/payables, bank reconciliation, cost centers, financial statements, VAT reports, zakat workpapers. ZATCA integration requires legal/technical verification; never assume compliance from QR alone.

## Branding
Primary #681B3B, white #FFFFFF, accent #B58A4C; preserve original logo unchanged except authorized recolor.

## Additional customer event design from supplied concept
Distinct bride and groom planning experiences, with optional shared event and scoped privacy controls; private tasks and budgets remain private unless explicitly shared.
