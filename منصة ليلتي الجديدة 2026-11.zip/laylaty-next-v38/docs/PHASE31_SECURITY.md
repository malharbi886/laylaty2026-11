# V31 — Security isolation hardening

## Changes
- Reject malformed, zero, nonnumeric, and overflowing tenant identifiers in ResolveTenant.
- Check actual tenant existence through join, and require explicit membership with an allowlisted role.
- Store authenticated tenant and role on request attributes; tenant ID from URL alone never authorizes access.
- Add domain tests for unknown roles, cross-tenant and cross-customer access policies.
- Add conservative static audit of authenticated route groups and flag controllers for manual review.

## Threat model and outstanding blockers
- URL IDOR, role escalation, tenant confusion, customer ownership, background jobs, uploads, exports, webhook signatures, and financial race conditions.
- Static inspection and unit tests do **not** prove complete isolation. Every controller, job, export, storage key, cache key, websocket channel and query needs end-to-end tenant tests.
- Current schema uses a shared MySQL database; MySQL has no PostgreSQL-style RLS. Application and composite foreign key enforcement are both necessary.
- Tenant membership status/revocation, branch-level permissions, global admin impersonation, and API rate limits need dedicated implementation and tests.
- The application is a Laravel-style skeleton, not an installed and tested Laravel application. No migrations executed.

## Mandatory release gates
1. Build complete Laravel app and run migrations **only** on approved disposable database.
2. Create tenant A/B and customer A/B; assert 404/403 on every cross-tenant ID in every endpoint, including nested resources.
3. Test parallel stock, payment, refund and shift operations using MySQL transactions.
4. Verify signed webhooks, replay protection, file authorization, rate limits, logging and secrets.
5. Independent security review and penetration testing before production.
