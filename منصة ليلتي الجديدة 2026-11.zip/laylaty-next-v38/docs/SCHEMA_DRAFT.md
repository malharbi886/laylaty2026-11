# Initial schema map — NOT a migration

- tenants(id, kind, name, status)
- users(id, phone, email); memberships(id, tenant_id, user_id, role_id, branch_id)
- roles(id, tenant_id, name); permissions(id, code); role_permissions(role_id, permission_id)
- branches(id, tenant_id, name); specialties(id, code, name); stores(id, tenant_id, specialty_id)
- halls(id, tenant_id, branch_id, name); hall_slots(id, tenant_id, hall_id, name)
- bookings(id, tenant_id, hall_id, slot_id, event_date, status, customer_id, version)
- booking_holds(id, tenant_id, hall_id, slot_id, event_date, expires_at)
- contracts(id, tenant_id, booking_id, version, status); contract_annexes(id, tenant_id, contract_id, version)
- orders(id, tenant_id, customer_id, status); order_lines(id, tenant_id, order_id, item_id)
- invoices(id, tenant_id, source_type, source_id, idempotency_key)
- payments(id, tenant_id, invoice_id, provider_reference, status)
- accounts(id, tenant_id, code, type); journal_entries(id, tenant_id, status, source_key)
- journal_lines(id, tenant_id, entry_id, account_id, debit_halalas, credit_halalas)
- subscriptions(id, tenant_id, plan_id, status); commissions(id, tenant_id, booking_id, amount_halalas)
- audit_events(id, tenant_id, actor_id, action, resource_id, created_at)

Constraints and indexes TBD after ERD review. Booking uniqueness must consider overlapping intervals and active holds, not only equal slot labels. Never execute this as SQL against existing data.
