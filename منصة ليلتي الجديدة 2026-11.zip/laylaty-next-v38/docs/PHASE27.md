# V27 — Partial refund quote (non-financial)
- Added authenticated tenant-scoped quotation API for a partial refund.
- Validates that the original sale is completed and not fully refunded.
- Reuses integer-halalas cumulative rounding logic.
- Added draft request schema for future refund workflow; **not connected to settlement**.
- Does not update stock, refund cash, or issue tax credit notes.
- WARNING: quotes do not reserve refundable quantities; they are NOT authorization to pay a refund.
- Remaining: partial refund execution with atomic quantity ledger, idempotency, receipt verification, tax adjustments, closed-shift handling, concurrency tests and full Laravel/MySQL integration.
- No migrations or real payments were run.
