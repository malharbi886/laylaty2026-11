# Laylaty Next — Coding Agent Rules

- New independent project. Do not modify existing Laylaty app, hall management program, repositories, or backups.
- Stack: Laravel/PHP backend, React/TypeScript frontend, MySQL; Arabic RTL first.
- Security: tenant isolation on every query, API, export, file, background job; RBAC per tenant/branch. Automated cross-tenant tests required.
- Financial: double-entry journal, immutable posted entries, compensating reversals, idempotent payments and webhooks. No real payment processing in development.
- No migrations against production or existing databases. Local disposable development database only after explicit user confirmation for migration execution.
- No production deployment, DNS change, secrets, or live ZATCA connection without separate approval.
- Hall owners: booking commission model; accounting optional paid subscription; NO POS for halls.
- Other merchants: subscriptions; POS capability by specialty; accounting isolated per tenant.
- Maintain test coverage, architecture decisions, and phase report. Run available static checks and tests before marking work complete.
- Begin with phase 0 inventory and architecture; do not claim completed functionality before implementing and testing it.
