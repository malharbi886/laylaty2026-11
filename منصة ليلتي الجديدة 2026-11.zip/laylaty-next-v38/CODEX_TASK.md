# مهمة Codex: بناء Laylaty Next من الصفر

## Objective
Build a modular Saudi wedding/events marketplace and operations platform in a new isolated repository. Preserve legacy systems; plan adapters rather than replacing them.

## Phase 0 — First action
1. Inspect repository, tooling and environment; read AGENTS.md and docs/REQUIREMENTS.md.
2. Scaffold a Laravel API and React/TypeScript frontend in apps/api and apps/web, only when prerequisites are available. Do not invent completed installation results.
3. Propose schema and ERD for tenant, users, memberships, roles, permissions, branches, specialties, stores, halls, time slots, booking holds, bookings, contracts, annexes, invoices, payments, ledger, subscription, commission, audit.
4. Implement tenant-scoping architecture and automated cross-tenant authorization tests first.
5. Commit in small reviewable increments; document every command and test result in docs/PHASE_REPORT.md.

## Delivery phases
P1: authentication, tenant isolation, RBAC, admin shell, merchant onboarding, 16 specialties, branches, catalog.
P2: halls: dual-calendar, slot availability, booking status, contracts, annexes, installments, audit and customer app adapters.
P3: merchant order and appointment modules, storefront, checkout stubs, event tasks and budget.
P4: POS for eligible specialties only, shifts, refunds, inventory; double-entry accounting and reconciliation.
P5: Saudi VAT/e-invoicing integration architecture, ZATCA validation, zakat worksheets, financial statements, with specialist compliance review.
P6: notifications, subscriptions/commissions, analytics, UX hardening and staging release checks.

## Acceptance gates
- No cross-tenant data leakage, including IDOR, background jobs and files.
- No double booking under concurrent requests.
- No duplicate invoice/journal entry on retries.
- Journal postings balance and are append-only with reversals.
- Hall module has no POS; basic booking finance remains accessible without accounting subscription.
- No claims of regulatory certification without verification.

## Immediate request
Start with Phase 0 and P1 only. Implement actual code and tests where environment permits, then report completed, blocked and next tasks. Do not run production migrations or real payments.


## V38 next security review
Review order cancellation reason, transaction-scoped audit, cross-tenant authorization, and direct audit inserts in all other controllers. Require Laravel/MySQL integration tests before release.
