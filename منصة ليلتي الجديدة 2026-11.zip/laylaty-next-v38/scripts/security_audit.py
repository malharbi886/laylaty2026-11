#!/usr/bin/env python3
"""Conservative static checks. Not a substitute for integration or penetration tests."""
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
routes=(root/'apps/api/routes/api.php').read_text()
failures=[]
if "Route::middleware(['auth:sanctum',ResolveTenant::class])->prefix('tenants/{tenant}')" not in routes:
    failures.append('Tenant API is missing the authenticated tenant middleware group')
if "Route::middleware('auth:sanctum')->group" not in routes:
    failures.append('Customer API is missing authenticated group')
for m in re.finditer(r"Route::(?:get|post|put|patch|delete)\('([^']+)'",routes):
    path=m.group(1)
    if path.startswith('public/') and not path.startswith('public/stores/'):
        failures.append(f'Unexpected unauthenticated route: {path}')
controllers=root/'apps/api/app/Http/Controllers/Api'
for f in controllers.glob('*.php'):
    src=f.read_text()
    # Flag obvious unscoped writes/reads for manual review; intentionally non-blocking.
    if 'DB::table(' in src and "where('tenant_id'" not in src and f.name!='CustomerEventController.php':
        print('REVIEW controller without literal tenant_id scope:',f.name)
print('Static security audit:', 'FAIL' if failures else 'PASS')
for issue in failures:print('FAIL:',issue)
sys.exit(1 if failures else 0)
