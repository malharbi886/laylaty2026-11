#!/usr/bin/env python3
"""Static route protection gate; does not replace Laravel authorization tests."""
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
source = (root/'apps/api/routes/api.php').read_text()
controllers = root/'apps/api/app/Http/Controllers/Api'
errors = []
# The tenant block must be explicitly authenticated AND tenant-scoped.
start = source.find("Route::middleware(['auth:sanctum',ResolveTenant::class])->prefix('tenants/{tenant}')")
if start < 0:
    errors.append('Missing authenticated tenant route group')
else:
    end = source.find('\n});', start)
    if end < 0:
        errors.append('Tenant route group closing marker missing')
    else:
        group = source[start:end]
        for line in group.splitlines():
            if 'Route::' in line and '::class' in line and 'ResolveTenant' not in line:
                if not re.search(r'\[\w+Controller::class,\s*\'\w+\'\]',line):
                    errors.append('Unrecognized route syntax: '+line.strip())
for name in set(re.findall(r'\[([A-Za-z]+Controller)::class',source)):
    if not (controllers/(name+'.php')).exists():
        errors.append('Missing controller: '+name)
# Customer private routes must remain inside an auth group.
for match in re.finditer(r"Route::(?:get|post|patch|put|delete)\('my/",source):
    # Only matches when the last auth middleware group starts before the route.
    preceding = source[:match.start()]
    if preceding.rfind("Route::middleware('auth:sanctum')") < 0:
        errors.append('Customer route missing auth group: '+str(match.start()))
# Public routes may not expose administrative or tenant-private resources.
for path in re.findall(r"Route::get\('public/([^']+)'",source):
    if any(word in path for word in ('audit','invoice','payment','private','staff')):
        errors.append('Sensitive public route: '+path)
if errors:
    print('FAIL:',*errors,sep='\n- '); sys.exit(1)
print('PASS: static route checks; dynamic authorization remains unverified')
