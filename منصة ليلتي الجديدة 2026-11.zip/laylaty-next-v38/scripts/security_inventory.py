#!/usr/bin/env python3
"""Conservative static inventory; findings are review candidates, not confirmed vulnerabilities."""
from pathlib import Path
import re, json
root=Path(__file__).resolve().parents[1]
controllers=root/'apps/api/app/Http/Controllers/Api'
results=[]
for file in sorted(controllers.glob('*.php')):
    text=file.read_text()
    tables=re.findall(r"DB::table\(['\"]([a-z_]+)['\"]\)",text)
    tenant_scopes=len(re.findall(r"->where\(['\"]tenant_id['\"]",text))
    ownership_scopes=len(re.findall(r"->where\(['\"]customer_id['\"]",text))
    if tables:
        results.append({'controller':file.name,'db_table_calls':len(tables),'tenant_where_calls':tenant_scopes,'customer_where_calls':ownership_scopes,'needs_manual_review':len(tables)>tenant_scopes+ownership_scopes})
routes=(root/'apps/api/routes/api.php').read_text()
assert "Route::middleware(['auth:sanctum',ResolveTenant::class])" in routes, 'Tenant route group lacks middleware'
assert "Route::middleware('auth:sanctum')" in routes, 'Customer route group lacks auth'
output={'warning':'Heuristic only; does not prove secure or insecure queries','controllers':results}
(root/'docs/SECURITY_QUERY_INVENTORY_V32.json').write_text(json.dumps(output,indent=2,ensure_ascii=False)+'\n')
print('Scanned',len(results),'controllers;',sum(x['needs_manual_review'] for x in results),'need manual query review')
