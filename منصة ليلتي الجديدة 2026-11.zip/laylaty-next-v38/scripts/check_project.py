#!/usr/bin/env python3
"""Read-only project checks. Does not run migrations or connect to databases."""
from pathlib import Path
import re,sys
root=Path(__file__).resolve().parents[1]
api=root/'apps/api'
routes=(api/'routes/api.php').read_text()
# Detect missing controller class references in routes
missing=[]
for cls in sorted(set(re.findall(r'\[(\w+)::class,',routes))):
 if cls=='Route':continue
 if not (api/'app/Http/Controllers/Api'/f'{cls}.php').exists():missing.append(cls)
if missing:print('Missing controllers:',', '.join(missing));sys.exit(1)
print('Controller references OK:',len(set(re.findall(r'\[(\w+)::class,',routes))))
print('NOTICE: static check only; no Laravel/MySQL/React runtime verification')
