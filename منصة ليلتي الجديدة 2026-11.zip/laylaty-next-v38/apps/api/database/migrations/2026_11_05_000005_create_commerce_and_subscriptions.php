<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('subscription_plans',function(Blueprint $t){$t->id();$t->string('code')->unique();$t->string('name');$t->unsignedBigInteger('price_halalas');$t->string('period');$t->boolean('active')->default(true);$t->timestamps();});
  Schema::create('store_subscriptions',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('plan_id')->constrained('subscription_plans');$t->string('status');$t->date('starts_on');$t->date('ends_on');$t->date('grace_until')->nullable();$t->timestamps();$t->index(['tenant_id','status']);});
  Schema::create('invoices',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('booking_id')->nullable();$t->string('invoice_number');$t->string('status')->default('draft');$t->unsignedBigInteger('subtotal_halalas');$t->unsignedBigInteger('vat_halalas');$t->unsignedBigInteger('total_halalas');$t->date('issued_on')->nullable();$t->json('buyer_snapshot')->nullable();$t->timestamps();$t->unique(['tenant_id','invoice_number']);$t->unique(['id','tenant_id']);$t->foreign(['booking_id','tenant_id'])->references(['id','tenant_id'])->on('bookings');});
  Schema::create('invoice_lines',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('invoice_id');$t->string('description');$t->unsignedInteger('quantity');$t->unsignedBigInteger('unit_price_halalas');$t->unsignedBigInteger('subtotal_halalas');$t->unsignedBigInteger('vat_halalas');$t->timestamps();$t->foreign(['invoice_id','tenant_id'])->references(['id','tenant_id'])->on('invoices');});
  Schema::create('commission_rules',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->unsignedInteger('basis_points');$t->date('effective_on');$t->timestamps();});
 }
 public function down():void {foreach(['commission_rules','invoice_lines','invoices','store_subscriptions','subscription_plans'] as $name)Schema::dropIfExists($name);}
};
