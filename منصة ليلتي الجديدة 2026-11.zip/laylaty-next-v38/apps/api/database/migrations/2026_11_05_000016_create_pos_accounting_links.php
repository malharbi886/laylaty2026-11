<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('pos_accounting_links',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();
   $t->foreignId('sale_id');$t->foreignId('journal_entry_id');
   $t->string('kind',16);$t->timestamps();
   $t->unique(['tenant_id','sale_id','kind']);
   $t->unique(['tenant_id','journal_entry_id']);
   $t->foreign(['journal_entry_id','tenant_id'])->references(['id','tenant_id'])->on('journal_entries');
   $t->foreign(['sale_id','tenant_id'])->references(['id','tenant_id'])->on('pos_sales');
  });
 }
 public function down():void {Schema::dropIfExists('pos_accounting_links');}
};
