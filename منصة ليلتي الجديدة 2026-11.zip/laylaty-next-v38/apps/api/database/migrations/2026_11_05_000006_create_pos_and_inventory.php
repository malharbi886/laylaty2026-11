<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('catalog_items',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->string('sku');$t->string('name');$t->string('kind')->default('product');$t->unsignedBigInteger('price_halalas');$t->boolean('active')->default(true);$t->timestamps();$t->unique(['tenant_id','sku']);$t->unique(['id','tenant_id']);});
  Schema::create('inventory_balances',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('item_id');$t->foreignId('branch_id');$t->integer('quantity')->default(0);$t->timestamps();$t->unique(['tenant_id','item_id','branch_id']);$t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');$t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');});
  Schema::create('pos_shifts',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');$t->unsignedBigInteger('opened_by');$t->unsignedBigInteger('closed_by')->nullable();$t->string('status')->default('open');$t->unsignedBigInteger('opening_cash_halalas')->default(0);$t->bigInteger('closing_difference_halalas')->nullable();$t->timestamp('closed_at')->nullable();$t->timestamps();$t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');$t->unique(['id','tenant_id']);});
  Schema::create('pos_sales',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('shift_id');$t->string('reference');$t->string('status')->default('draft');$t->unsignedBigInteger('total_halalas');$t->timestamps();$t->unique(['tenant_id','reference']);$t->foreign(['shift_id','tenant_id'])->references(['id','tenant_id'])->on('pos_shifts');});
 }
 public function down():void {foreach(['pos_sales','pos_shifts','inventory_balances','catalog_items'] as $name)Schema::dropIfExists($name);}
};
