<?php
use App\Domain\Tenancy\TenantPublicId;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('public_id', 7)->nullable()->unique();
        });
        // Backfill existing tenants without overwriting any previously assigned public ID.
        DB::table('tenants')->whereNull('public_id')->orderBy('id')->chunkById(200, function ($tenants) {
            foreach ($tenants as $tenant) {
                for ($attempt = 0; $attempt < 8; $attempt++) {
                    try {
                        DB::table('tenants')->where('id', $tenant->id)->whereNull('public_id')
                            ->update(['public_id' => TenantPublicId::generate()]);
                        break;
                    } catch (\Illuminate\Database\UniqueConstraintViolationException $e) {
                        if ($attempt === 7) throw $e;
                    }
                }
            }
        });
        // Enforce non-null after backfill; requires DBAL-compatible Laravel schema support.
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('public_id', 7)->nullable(false)->change();
        });
    }
    public function down(): void {
        Schema::table('tenants', fn (Blueprint $table) => $table->dropUnique(['public_id']));
        Schema::table('tenants', fn (Blueprint $table) => $table->dropColumn('public_id'));
    }
};
