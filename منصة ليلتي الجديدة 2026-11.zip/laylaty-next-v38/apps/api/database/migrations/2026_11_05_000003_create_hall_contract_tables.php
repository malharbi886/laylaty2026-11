<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('halls',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();
   $t->foreignId('branch_id');
   $t->string('name');$t->string('timezone')->default('Asia/Riyadh');
   $t->boolean('is_active')->default(true);$t->timestamps();
   $t->unique(['id','tenant_id']);$t->unique(['id','tenant_id','branch_id']);
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
  });
  Schema::table('bookings',function(Blueprint $t){
   $t->unsignedBigInteger('hall_id')->nullable()->after('branch_id');
   $t->foreign(['hall_id','tenant_id','branch_id'])->references(['id','tenant_id','branch_id'])->on('halls');
  });
  Schema::create('booking_contracts',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('booking_id');
   $t->unsignedInteger('version');$t->string('status')->default('draft');
   $t->json('terms_snapshot');$t->timestamp('approved_at')->nullable();
   $t->unsignedBigInteger('approved_by')->nullable();$t->timestamps();
   $t->unique(['tenant_id','booking_id','version']);
   $t->foreign(['booking_id','tenant_id'])->references(['id','tenant_id'])->on('bookings');
   $t->unique(['id','tenant_id']);
  });
  Schema::create('contract_service_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('contract_id');
   $t->string('name');$t->unsignedInteger('quantity')->default(1);
   $t->unsignedBigInteger('unit_price_halalas');$t->unsignedBigInteger('line_total_halalas');
   $t->timestamps();
   $t->foreign(['contract_id','tenant_id'])->references(['id','tenant_id'])->on('booking_contracts');
  });
 }
 public function down():void {
  Schema::dropIfExists('contract_service_lines');
  Schema::dropIfExists('booking_contracts');
  Schema::table('bookings',function(Blueprint $t){$t->dropForeign(['hall_id','tenant_id','branch_id']);$t->dropColumn('hall_id');});
  Schema::dropIfExists('halls');
 }
};
