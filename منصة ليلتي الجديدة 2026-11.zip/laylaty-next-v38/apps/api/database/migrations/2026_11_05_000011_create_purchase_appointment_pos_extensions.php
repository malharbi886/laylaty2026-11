<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('store_purchase_orders',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');$t->foreignId('supplier_id');
   $t->string('reference',100);$t->string('status',24)->default('draft');$t->unsignedBigInteger('total_halalas');
   $t->timestamps();$t->unique(['tenant_id','reference']);$t->unique(['id','tenant_id']);
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
   $t->foreign(['supplier_id','tenant_id'])->references(['id','tenant_id'])->on('store_suppliers');
  });
  Schema::create('store_purchase_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('purchase_id');$t->foreignId('item_id');
   $t->unsignedInteger('quantity');$t->unsignedBigInteger('unit_cost_halalas');$t->unsignedBigInteger('line_total_halalas');$t->timestamps();
   $t->foreign(['purchase_id','tenant_id'])->references(['id','tenant_id'])->on('store_purchase_orders');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
  Schema::create('store_appointments',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');$t->foreignId('item_id');
   $t->string('resource_key',120);$t->dateTime('starts_at');$t->dateTime('ends_at');
   $t->string('status',24)->default('confirmed');$t->unsignedBigInteger('customer_id')->nullable();
   $t->timestamps();$t->index(['tenant_id','branch_id','resource_key','starts_at']);
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
  Schema::table('pos_shifts',function(Blueprint $t){$t->unsignedBigInteger('counted_cash_halalas')->nullable();});
 }
 public function down():void {
  Schema::table('pos_shifts',function(Blueprint $t){$t->dropColumn('counted_cash_halalas');});
  Schema::dropIfExists('store_appointments');Schema::dropIfExists('store_purchase_lines');Schema::dropIfExists('store_purchase_orders');
 }
};
