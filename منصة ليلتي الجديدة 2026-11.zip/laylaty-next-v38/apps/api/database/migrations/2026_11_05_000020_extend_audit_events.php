<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::table('audit_events', function(Blueprint $t) {
   $t->string('actor_role', 64)->nullable();
   $t->string('source', 32)->nullable();
   $t->string('request_id', 128)->nullable();
   $t->ipAddress('ip_address')->nullable();
   $t->index(['tenant_id','created_at','id'], 'audit_tenant_time_idx');
   $t->index(['tenant_id','actor_id','created_at'], 'audit_actor_time_idx');
  });
 }
 public function down():void {
  Schema::table('audit_events', function(Blueprint $t) {
   $t->dropIndex('audit_tenant_time_idx'); $t->dropIndex('audit_actor_time_idx');
   $t->dropColumn(['actor_role','source','request_id','ip_address']);
  });
 }
};
