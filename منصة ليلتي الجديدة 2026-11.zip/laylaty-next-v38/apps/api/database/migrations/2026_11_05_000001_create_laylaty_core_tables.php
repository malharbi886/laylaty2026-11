<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('tenants',function(Blueprint $t){$t->id();$t->string('name');$t->string('type');$t->timestamps();});
  Schema::create('branches',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->string('name');$t->timestamps();$t->unique(['id','tenant_id']);});
  Schema::create('tenant_memberships',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->unsignedBigInteger('user_id');$t->string('role');$t->timestamps();$t->unique(['tenant_id','user_id']);});
  Schema::create('bookings',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');$t->string('reference')->unique();$t->string('status')->default('pending');$t->dateTime('starts_at');$t->dateTime('ends_at');$t->bigInteger('total_halalas')->default(0);$t->timestamps();$t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');$t->index(['tenant_id','starts_at']);});
  Schema::create('booking_payments',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('booking_id');$t->bigInteger('amount_halalas');$t->string('status')->default('pending');$t->string('method');$t->string('external_reference')->nullable();$t->timestamps();$t->foreign(['booking_id','tenant_id'])->references(['id','tenant_id'])->on('bookings');$t->unique(['tenant_id','external_reference']);});
  Schema::create('audit_events',function(Blueprint $t){$t->id();$t->foreignId('tenant_id')->nullable()->constrained();$t->unsignedBigInteger('actor_id')->nullable();$t->string('event');$t->string('resource_type');$t->string('resource_id');$t->json('details')->nullable();$t->timestamps();});
 }
 public function down():void {foreach(['audit_events','booking_payments','bookings','tenant_memberships','branches','tenants'] as $name)Schema::dropIfExists($name);}
};
