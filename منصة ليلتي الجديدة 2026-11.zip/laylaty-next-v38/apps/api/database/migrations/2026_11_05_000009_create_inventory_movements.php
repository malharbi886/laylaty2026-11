<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('inventory_movements',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');$t->foreignId('item_id');
   $t->string('reference',100);$t->string('kind',30);$t->integer('delta');
   $t->integer('quantity_before');$t->integer('quantity_after');$t->unsignedBigInteger('actor_id');
   $t->string('reason',500);$t->timestamps();
   $t->unique(['tenant_id','reference']);
   $t->index(['tenant_id','branch_id','item_id','created_at'],'inventory_movements_lookup');
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
 }
 public function down():void {Schema::dropIfExists('inventory_movements');}
};
