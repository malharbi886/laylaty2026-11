<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('store_suppliers',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->string('name');$t->string('contact')->nullable();
   $t->timestamps();$t->unique(['id','tenant_id']);
  });
  Schema::create('store_stock_transfers',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->string('reference',80);
   $t->foreignId('source_branch_id');$t->foreignId('destination_branch_id');$t->foreignId('item_id');
   $t->unsignedInteger('quantity');$t->unsignedBigInteger('created_by');$t->timestamps();
   $t->unique(['tenant_id','reference']);
   $t->foreign(['source_branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
   $t->foreign(['destination_branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
 }
 public function down():void {Schema::dropIfExists('store_stock_transfers');Schema::dropIfExists('store_suppliers');}
};
