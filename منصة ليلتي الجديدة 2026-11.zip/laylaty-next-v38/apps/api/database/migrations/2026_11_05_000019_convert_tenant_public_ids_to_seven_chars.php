<?php
use App\Domain\Tenancy\TenantPublicId;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        // Existing 24-character IDs cannot be shortened without changing public URLs.
        // Stop and perform a separately approved, coordinated migration if any exist.
        $existing = DB::table('tenants')->whereNotNull('public_id')->first();
        if ($existing && strlen((string) $existing->public_id) !== 7) {
            throw new \RuntimeException('Existing V34 public IDs detected. Coordinate URL/API migration and preserve an alias map before converting. No data changed.');
        }
        // For fresh installs migration 000018 already creates VARCHAR(7).
        // No data mutation is needed here.
    }
    public function down(): void {
        // Intentionally no-op: reverting identifier formats could break public URLs.
    }
};
