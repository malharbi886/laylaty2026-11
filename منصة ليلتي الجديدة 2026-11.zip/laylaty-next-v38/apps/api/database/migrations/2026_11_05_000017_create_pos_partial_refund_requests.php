<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::table('pos_sale_lines',function(Blueprint $t){$t->unique(['id','tenant_id']);});
  Schema::create('pos_partial_refund_requests',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('sale_id');
   $t->string('request_key',100);$t->string('status',20)->default('draft');
   $t->unsignedBigInteger('quoted_total_halalas');$t->string('reason',500);
   $t->unsignedBigInteger('requested_by');$t->timestamps();
   $t->unique(['tenant_id','request_key']);$t->unique(['id','tenant_id']);
   $t->foreign(['sale_id','tenant_id'])->references(['id','tenant_id'])->on('pos_sales');
  });
  Schema::create('pos_partial_refund_request_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('request_id');
   $t->foreignId('sale_line_id');$t->unsignedInteger('quantity');
   $t->unsignedBigInteger('quoted_amount_halalas');$t->timestamps();
   $t->unique(['request_id','sale_line_id']);
   $t->foreign(['request_id','tenant_id'])->references(['id','tenant_id'])->on('pos_partial_refund_requests');
   $t->foreign(['sale_line_id','tenant_id'])->references(['id','tenant_id'])->on('pos_sale_lines');
  });
 }
 public function down():void {Schema::dropIfExists('pos_partial_refund_request_lines');Schema::dropIfExists('pos_partial_refund_requests');Schema::table('pos_sale_lines',function(Blueprint $t){$t->dropUnique(['id','tenant_id']);});}
};
