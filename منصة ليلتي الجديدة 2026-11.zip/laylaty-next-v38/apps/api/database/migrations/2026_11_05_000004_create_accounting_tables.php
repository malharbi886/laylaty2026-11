<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('ledger_accounts',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();
   $t->string('code',32);$t->string('name');$t->string('type',24);
   $t->boolean('active')->default(true);$t->timestamps();
   $t->unique(['tenant_id','code']);$t->unique(['id','tenant_id']);
  });
  Schema::create('journal_entries',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();
   $t->string('reference',100);$t->string('status',16)->default('draft');
   $t->date('entry_date');$t->text('description')->nullable();
   $t->unsignedBigInteger('created_by');$t->unsignedBigInteger('posted_by')->nullable();
   $t->timestamp('posted_at')->nullable();$t->timestamps();
   $t->unique(['tenant_id','reference']);$t->unique(['id','tenant_id']);
  });
  Schema::create('journal_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();
   $t->foreignId('journal_entry_id');$t->foreignId('ledger_account_id');
   $t->unsignedBigInteger('debit_halalas')->default(0);
   $t->unsignedBigInteger('credit_halalas')->default(0);$t->timestamps();
   $t->foreign(['journal_entry_id','tenant_id'])->references(['id','tenant_id'])->on('journal_entries');
   $t->foreign(['ledger_account_id','tenant_id'])->references(['id','tenant_id'])->on('ledger_accounts');
  });
 }
 public function down():void {
  Schema::dropIfExists('journal_lines');
  Schema::dropIfExists('journal_entries');
  Schema::dropIfExists('ledger_accounts');
 }
};
