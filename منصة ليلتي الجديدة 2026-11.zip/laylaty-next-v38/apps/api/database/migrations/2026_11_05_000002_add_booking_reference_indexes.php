<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::table('bookings',function(Blueprint $table){
   $table->index(['tenant_id','branch_id','status','starts_at','ends_at'],'bookings_slot_lookup');
   $table->unique(['id','tenant_id'],'bookings_id_tenant_unique');
  });
 }
 public function down():void {
  Schema::table('bookings',function(Blueprint $table){
   $table->dropIndex('bookings_slot_lookup');
   $table->dropUnique('bookings_id_tenant_unique');
  });
 }
};
