<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('customer_events',function(Blueprint $t){$t->id();$t->unsignedBigInteger('customer_id');$t->string('occasion_type');$t->string('title');$t->date('event_date');$t->string('city');$t->string('location_text')->nullable();$t->unsignedBigInteger('budget_halalas')->nullable();$t->timestamps();$t->unique(['id','customer_id']);});
  Schema::create('event_tasks',function(Blueprint $t){$t->id();$t->foreignId('event_id')->constrained('customer_events');$t->string('title');$t->string('specialty_code')->nullable();$t->string('status')->default('todo');$t->unsignedInteger('sort_order')->default(0);$t->unsignedBigInteger('booking_id')->nullable();$t->unsignedBigInteger('order_id')->nullable();$t->timestamps();$t->index(['event_id','sort_order']);});
  Schema::create('notification_outbox',function(Blueprint $t){$t->id();$t->string('channel');$t->string('template_code');$t->string('recipient_key');$t->json('payload');$t->string('status')->default('pending');$t->string('idempotency_key')->unique();$t->timestamp('next_attempt_at')->nullable();$t->unsignedInteger('attempts')->default(0);$t->timestamps();});
  Schema::create('integration_events',function(Blueprint $t){$t->id();$t->string('source');$t->string('external_event_id');$t->string('event_type');$t->json('payload');$t->string('status')->default('received');$t->timestamps();$t->unique(['source','external_event_id']);});
 }
 public function down():void {foreach(['integration_events','notification_outbox','event_tasks','customer_events'] as $name)Schema::dropIfExists($name);}
};
