<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('store_stocktakes',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');
   $t->string('reference',100);$t->string('status',24)->default('draft');
   $t->unsignedBigInteger('created_by');$t->timestamps();
   $t->unique(['tenant_id','reference']);$t->unique(['id','tenant_id']);
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
  });
  Schema::create('store_stocktake_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('stocktake_id');$t->foreignId('item_id');
   $t->unsignedInteger('recorded_quantity');$t->unsignedInteger('counted_quantity');$t->integer('variance');$t->timestamps();
   $t->unique(['stocktake_id','item_id']);
   $t->foreign(['stocktake_id','tenant_id'])->references(['id','tenant_id'])->on('store_stocktakes');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
  Schema::create('pos_sale_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('sale_id');$t->foreignId('item_id');
   $t->string('name_snapshot');$t->unsignedInteger('quantity');$t->unsignedBigInteger('unit_price_halalas');
   $t->unsignedBigInteger('line_total_halalas');$t->timestamps();
   $t->foreign(['sale_id','tenant_id'])->references(['id','tenant_id'])->on('pos_sales');
   $t->foreign(['item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
  Schema::table('pos_sales',function(Blueprint $t){$t->unique(['id','tenant_id']);});
 }
 public function down():void {
  Schema::dropIfExists('pos_sale_lines');Schema::dropIfExists('store_stocktake_lines');Schema::dropIfExists('store_stocktakes');
  Schema::table('pos_sales',function(Blueprint $t){$t->dropUnique(['id','tenant_id']);});
 }
};
