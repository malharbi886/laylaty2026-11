<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('store_profiles',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->unique()->constrained();
   $t->string('slug')->unique();$t->string('specialty_id',64);
   $t->string('status')->default('draft');$t->text('description')->nullable();$t->timestamps();
  });
  Schema::create('merchant_orders',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('branch_id');
   $t->string('reference')->unique();$t->string('status')->default('new');
   $t->unsignedBigInteger('total_halalas');$t->timestamp('delivery_at')->nullable();$t->timestamps();
   $t->unique(['id','tenant_id']);
   $t->foreign(['branch_id','tenant_id'])->references(['id','tenant_id'])->on('branches');
  });
  Schema::create('merchant_order_lines',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('merchant_order_id');
   $t->foreignId('catalog_item_id');$t->string('name_snapshot');
   $t->unsignedInteger('quantity');$t->unsignedBigInteger('unit_price_halalas');
   $t->unsignedBigInteger('line_total_halalas');$t->timestamps();
   $t->foreign(['merchant_order_id','tenant_id'])->references(['id','tenant_id'])->on('merchant_orders');
   $t->foreign(['catalog_item_id','tenant_id'])->references(['id','tenant_id'])->on('catalog_items');
  });
 }
 public function down():void {
  Schema::dropIfExists('merchant_order_lines');
  Schema::dropIfExists('merchant_orders');
  Schema::dropIfExists('store_profiles');
 }
};
