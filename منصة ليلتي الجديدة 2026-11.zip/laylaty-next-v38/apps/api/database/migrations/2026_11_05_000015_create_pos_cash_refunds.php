<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up():void {
  Schema::create('pos_cash_refunds',function(Blueprint $t){
   $t->id();$t->foreignId('tenant_id')->constrained();$t->foreignId('sale_id');
   $t->unsignedBigInteger('amount_halalas');$t->unsignedBigInteger('refunded_by');
   $t->string('reason',500);$t->timestamps();
   $t->unique(['tenant_id','sale_id']);
   $t->foreign(['sale_id','tenant_id'])->references(['id','tenant_id'])->on('pos_sales');
  });
 }
 public function down():void {Schema::dropIfExists('pos_cash_refunds');}
};
