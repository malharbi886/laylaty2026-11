<?php
declare(strict_types=1);
namespace App\Domain\Contracts;
use InvalidArgumentException;
final class ContractMath {
 public static function servicesTotal(array $lines):int {
  $sum=0;
  foreach($lines as $line){
   $qty=$line['quantity']??null;$unit=$line['unit_price_halalas']??null;
   if(!is_int($qty)||$qty<1||!is_int($unit)||$unit<0)
    throw new InvalidArgumentException('Invalid contract service line');
   $sum+=($qty*$unit);
   if($sum>PHP_INT_MAX/2)throw new InvalidArgumentException('Total exceeds supported range');
  }
  return $sum;
 }
}
