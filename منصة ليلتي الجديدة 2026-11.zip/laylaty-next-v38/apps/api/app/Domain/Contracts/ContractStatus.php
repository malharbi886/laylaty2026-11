<?php
declare(strict_types=1);
namespace App\Domain\Contracts;
use DomainException;
final class ContractStatus {
 public static function approve(string $status): string {
  if($status!=='draft') throw new DomainException('Only draft contracts may be approved');
  return 'approved';
 }
}
