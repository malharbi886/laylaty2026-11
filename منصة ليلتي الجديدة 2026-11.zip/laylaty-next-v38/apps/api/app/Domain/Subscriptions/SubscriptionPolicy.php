<?php
declare(strict_types=1);
namespace App\Domain\Subscriptions;
use DomainException;
final class SubscriptionPolicy {
 public static function eligible(string $tenantType,string $product):bool {
  if(!in_array($tenantType,['hall','store'],true))throw new DomainException('Invalid tenant type');
  return $tenantType==='store'||$product==='advanced_accounting';
 }
 public static function status(string $today,string $endsOn,?string $graceUntil):string {
  foreach(array_filter([$today,$endsOn,$graceUntil]) as $d)if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$d))throw new DomainException('Invalid date');
  if($today<=$endsOn)return 'active';
  if($graceUntil!==null&&$today<=$graceUntil)return 'grace';
  return 'expired';
 }
}
