<?php
declare(strict_types=1);
namespace App\Domain\Notifications;
use DomainException;
final class IdempotencyKey {
 public static function build(string $channel,string $template,string $recipient,string $eventId):string {
  foreach([$channel,$template,$recipient,$eventId] as $value)if(trim($value)==='')throw new DomainException('Empty key component');
  return hash('sha256',json_encode([$channel,$template,$recipient,$eventId],JSON_THROW_ON_ERROR));
 }
}
