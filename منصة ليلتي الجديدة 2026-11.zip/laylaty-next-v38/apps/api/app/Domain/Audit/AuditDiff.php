<?php
declare(strict_types=1);
namespace App\Domain\Audit;

/** Explicit allowlist avoids accidental storage of secrets or customer PII. */
final class AuditDiff {
    public static function between(array $before, array $after, array $allowedFields): array {
        $changes = [];
        foreach ($allowedFields as $field) {
            if (!is_string($field) || !array_key_exists($field, $before) || !array_key_exists($field, $after)) continue;
            if ($before[$field] !== $after[$field]) {
                $changes[$field] = ['before' => $before[$field], 'after' => $after[$field]];
            }
        }
        return $changes;
    }
}
