<?php
declare(strict_types=1);
namespace App\Domain\Audit;

final class AuditAccess {
    public static function canReadTenantLog(string $role): bool { return $role === 'owner'; }
    public static function canReadCentralLog(string $role): bool { return $role === 'platform_auditor'; }
}
