<?php
declare(strict_types=1);
namespace App\Domain\Audit;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/** Invoke within the SAME database transaction as the business mutation. */
final class AuditRecorder {
    public static function record(Request $request, int $tenant, string $event, string $resourceType, string $resourceId, array $changes = [], ?string $reason = null): void {
        if ($tenant <= 0 || !$request->user()) throw new \DomainException('Authenticated tenant required');
        DB::table('audit_events')->insert([
            'tenant_id' => $tenant,
            'actor_id' => (int) $request->user()->id,
            'event' => $event,
            'resource_type' => $resourceType,
            'resource_id' => $resourceId,
            'details' => json_encode(['changes' => $changes, 'reason' => $reason], JSON_THROW_ON_ERROR),
            'actor_role' => (string) $request->attributes->get('laylaty_role'),
            'source' => 'api',
            'request_id' => (string) $request->headers->get('X-Request-ID', ''),
            'ip_address' => $request->ip(),
            'created_at' => now(), 'updated_at' => now(),
        ]);
    }
}
