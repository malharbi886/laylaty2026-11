<?php
declare(strict_types=1);
namespace App\Domain\Accounting;
use DomainException;
final class PosJournalDraft {
 public static function lines(string $kind,int $amount,int $cashAccount,int $salesAccount):array {
  if(!in_array($kind,['sale','refund'],true)||$amount<1||$cashAccount<1||$salesAccount<1||$cashAccount===$salesAccount)
   throw new DomainException('Invalid POS journal input');
  $lines=$kind==='sale' ? [
   ['account_id'=>$cashAccount,'debit_halalas'=>$amount,'credit_halalas'=>0],
   ['account_id'=>$salesAccount,'debit_halalas'=>0,'credit_halalas'=>$amount]
  ] : [
   ['account_id'=>$salesAccount,'debit_halalas'=>$amount,'credit_halalas'=>0],
   ['account_id'=>$cashAccount,'debit_halalas'=>0,'credit_halalas'=>$amount]
  ];
  JournalValidator::validate($lines);
  return $lines;
 }
}
