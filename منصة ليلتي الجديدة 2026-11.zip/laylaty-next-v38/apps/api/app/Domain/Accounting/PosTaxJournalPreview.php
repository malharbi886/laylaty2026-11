<?php
declare(strict_types=1);
namespace App\Domain\Accounting;
use DomainException;
/** Advisory VAT split only; does not establish legal VAT treatment or post a journal. */
final class PosTaxJournalPreview {
 public static function build(int $grossHalalas,int $vatBasisPoints,int $cashAccount,int $revenueAccount,int $vatAccount):array {
  if($grossHalalas<=0||$grossHalalas>PHP_INT_MAX-10000||$vatBasisPoints<0||$vatBasisPoints>10000)throw new DomainException('Invalid amount or VAT rate');
  if(min($cashAccount,$revenueAccount,$vatAccount)<1||count(array_unique([$cashAccount,$revenueAccount,$vatAccount]))!==3)
   throw new DomainException('Distinct account IDs required');
  // Round net amount half-up to the nearest halala, without multiplying huge integers.
  $denominator=10000+$vatBasisPoints;
  $whole=intdiv($grossHalalas,$denominator);
  $remainder=$grossHalalas%$denominator;
  $net=$whole*10000+intdiv($remainder*10000+intdiv($denominator,2),$denominator);
  $tax=$grossHalalas-$net;
  $lines=[
   ['account_id'=>$cashAccount,'debit_halalas'=>$grossHalalas,'credit_halalas'=>0],
   ['account_id'=>$revenueAccount,'debit_halalas'=>0,'credit_halalas'=>$net]
  ];
  if($tax>0)$lines[]=['account_id'=>$vatAccount,'debit_halalas'=>0,'credit_halalas'=>$tax];
  JournalValidator::validate($lines);
  return ['net_halalas'=>$net,'vat_halalas'=>$tax,'gross_halalas'=>$grossHalalas,'lines'=>$lines,
   'warning'=>'Preview only. VAT eligibility, invoices, refunds, and COGS require separate verification.'];
 }
}
