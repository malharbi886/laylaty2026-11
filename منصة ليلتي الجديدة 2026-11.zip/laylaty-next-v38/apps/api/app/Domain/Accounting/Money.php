<?php
declare(strict_types=1);
namespace App\Domain\Accounting;
use InvalidArgumentException;
final class Money {
 public static function remaining(int $totalHalalas, array $approvedPaymentsHalalas): int {
  if($totalHalalas<0) throw new InvalidArgumentException('Invalid total');
  $sum=0;
  foreach($approvedPaymentsHalalas as $payment) {
   if(!is_int($payment)||$payment<0) throw new InvalidArgumentException('Invalid payment');
   $sum+=$payment;
  }
  if($sum>$totalHalalas) throw new InvalidArgumentException('Overpayment requires explicit credit/refund handling');
  return $totalHalalas-$sum;
 }
}
