<?php
declare(strict_types=1);
namespace App\Domain\Accounting;
use DomainException;
final class JournalStatus {
 public static function post(string $status):string {
  if($status!=='draft') throw new DomainException('Only draft journals may be posted');
  return 'posted';
 }
}
