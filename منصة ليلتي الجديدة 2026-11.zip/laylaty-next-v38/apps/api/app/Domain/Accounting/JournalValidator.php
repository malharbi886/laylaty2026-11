<?php
declare(strict_types=1);
namespace App\Domain\Accounting;
use DomainException;
final class JournalValidator {
 public static function validate(array $lines): void {
  if(count($lines)<2) throw new DomainException('At least two lines required');
  $debits=0;$credits=0;
  foreach($lines as $line) {
   $d=$line['debit_halalas']??null;$c=$line['credit_halalas']??null;
   if(!is_int($d)||!is_int($c)||$d<0||$c<0||($d===0&&$c===0)||($d>0&&$c>0))
    throw new DomainException('Invalid journal line');
   if($d>PHP_INT_MAX-$debits||$c>PHP_INT_MAX-$credits)
    throw new DomainException('Journal amount overflow');
   $debits+=$d;$credits+=$c;
  }
  if($debits!==$credits) throw new DomainException('Unbalanced journal');
 }
}
