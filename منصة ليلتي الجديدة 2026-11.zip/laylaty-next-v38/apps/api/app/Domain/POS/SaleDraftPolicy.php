<?php
declare(strict_types=1);
namespace App\Domain\POS;
use DomainException;
final class SaleDraftPolicy {
 public static function cancel(string $status):string {
  if($status!=='draft')throw new DomainException('Only draft sales can be cancelled');
  return 'cancelled';
 }
 public static function canCloseShift(array $saleStatuses):bool {
  foreach($saleStatuses as $status)if($status!=='cancelled')return false;
  return true;
 }
}
