<?php
declare(strict_types=1);
namespace App\Domain\POS;
use DomainException;
/** Pure validation only; does not issue refunds or mutate inventory. */
final class PartialRefundPolicy {
 public static function calculate(array $soldLines,array $previousRefunded,array $requested):array {
  if(!$requested)throw new DomainException('Refund must contain lines');
  $sold=[];
  foreach($soldLines as $line){
   $id=$line['line_id']??null;$qty=$line['quantity']??null;$total=$line['line_total_halalas']??null;
   if(!is_int($id)||$id<1||isset($sold[$id])||!is_int($qty)||$qty<1||!is_int($total)||$total<0)
    throw new DomainException('Invalid original sale lines');
   $sold[$id]=['quantity'=>$qty,'total'=>$total];
  }
  $result=[];$refundTotal=0;
  foreach($requested as $id=>$qty){
   if(!is_int($id)&&!(is_string($id)&&ctype_digit($id)))throw new DomainException('Invalid line identifier');
   $id=(int)$id;
   if(!isset($sold[$id])||!is_int($qty)||$qty<1)throw new DomainException('Invalid requested refund');
   $prior=$previousRefunded[$id]??0;$original=$sold[$id]['quantity'];
   if(!is_int($prior)||$prior<0||$prior>$original||$qty>$original-$prior)
    throw new DomainException('Refund exceeds available quantity');
   $gross=$sold[$id]['total'];
   // Cumulative allocation ensures rounding never exceeds the original sale line total.
   $before=self::roundedRatio($gross,$prior,$original);
   $after=self::roundedRatio($gross,$prior+$qty,$original);
   $amount=$after-$before;
   if($amount>PHP_INT_MAX-$refundTotal)throw new DomainException('Refund overflow');
   $refundTotal+=$amount;
   $result[]=['line_id'=>$id,'quantity'=>$qty,'amount_halalas'=>$amount];
  }
  return ['lines'=>$result,'total_halalas'=>$refundTotal];
 }
 private static function roundedRatio(int $amount,int $quantity,int $denominator):int {
  // Avoid multiplying large integers; exact half-up integer rounding.
  $whole=intdiv($amount,$denominator);
  $remainder=$amount%$denominator;
  $base=$whole*$quantity;
  if($remainder===0)return $base;
  $fraction=$remainder*$quantity;
  return $base+intdiv($fraction,$denominator)+(($fraction%$denominator)*2 >= $denominator?1:0);
 }
}
