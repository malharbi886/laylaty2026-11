<?php
declare(strict_types=1);
namespace App\Domain\POS;
use DomainException;
final class CashSalePolicy {
 public static function complete(string $saleStatus,string $shiftStatus):string {
  if($shiftStatus!=='open'||$saleStatus!=='draft')throw new DomainException('Open shift and draft sale required');
  return 'completed';
 }
 public static function expectedCash(int $opening,array $sales):int {
  if($opening<0)throw new DomainException('Invalid opening cash');
  $total=$opening;
  foreach($sales as $amount){
   if(!is_int($amount)||$amount<0||$amount>PHP_INT_MAX-$total)throw new DomainException('Invalid sale amount');
   $total+=$amount;
  }
  return $total;
 }
}
