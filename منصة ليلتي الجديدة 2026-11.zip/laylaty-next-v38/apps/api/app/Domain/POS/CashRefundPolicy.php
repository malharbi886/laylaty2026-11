<?php
declare(strict_types=1);
namespace App\Domain\POS;
use DomainException;
final class CashRefundPolicy {
 public static function authorize(string $sale,string $shift,int $receipt,int $prior):void {
  if($sale!=='completed'||$shift!=='open'||$receipt<=0||$prior!==0)
   throw new DomainException('Full refund requires completed cash sale, open shift and no previous refund');
 }
 public static function expectedCash(int $opening,int $receipts,int $refunds):int {
  if($opening<0||$receipts<0||$refunds<0||$receipts>PHP_INT_MAX-$opening)
   throw new DomainException('Invalid cash totals');
  $gross=$opening+$receipts;
  if($refunds>$gross)throw new DomainException('Refund exceeds cash');
  return $gross-$refunds;
 }
}
