<?php
declare(strict_types=1);
namespace App\Domain\POS;
use DomainException;
final class ShiftCalculator {
 public static function cashDifference(int $opening,int $cashSales,int $cashRefunds,int $cashWithdrawals,int $counted):int {
  foreach([$opening,$cashSales,$cashRefunds,$cashWithdrawals,$counted] as $value)if($value<0)throw new DomainException('Negative cash component');
  $expected=$opening+$cashSales-$cashRefunds-$cashWithdrawals;
  if($expected<0)throw new DomainException('Invalid expected cash');
  return $counted-$expected;
 }
}
