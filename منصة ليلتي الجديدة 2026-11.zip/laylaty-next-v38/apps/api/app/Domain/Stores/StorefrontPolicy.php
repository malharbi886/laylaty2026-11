<?php
declare(strict_types=1);
namespace App\Domain\Stores;
use DomainException;
final class StorefrontPolicy {
 public static function slug(string $value):string {
  $value=strtolower(trim($value));
  if(!preg_match('/^[a-z0-9](?:[a-z0-9-]{1,58}[a-z0-9])?$/D',$value))throw new DomainException('Invalid slug');
  return $value;
 }
 public static function publicStatus(string $status):bool{return $status==='published';}
 public static function taskStatus(string $current,string $next):void {
  $transitions=['todo'=>['in_progress','cancelled'],'in_progress'=>['done','cancelled'],'done'=>[],'cancelled'=>[]];
  if(!in_array($next,$transitions[$current]??[],true))throw new DomainException('Invalid task transition');
 }
}
