<?php
declare(strict_types=1);
namespace App\Domain\Commissions;
use DomainException;
final class HallCommission {
 public static function amount(int $bookingBaseHalalas,int $basisPoints):int {
  if($bookingBaseHalalas<0||$bookingBaseHalalas>100000000000||$basisPoints<0||$basisPoints>10000)throw new DomainException('Invalid commission');
  return intdiv($bookingBaseHalalas*$basisPoints+5000,10000);
 }
}
