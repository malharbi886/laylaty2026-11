<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;
use DomainException;
final class TenantGuard {
 public static function assertSameTenant(int $actorTenantId,int $resourceTenantId): void {
  if($actorTenantId<=0||$resourceTenantId<=0||$actorTenantId!==$resourceTenantId)
   throw new DomainException('Resource not accessible');
 }
}
