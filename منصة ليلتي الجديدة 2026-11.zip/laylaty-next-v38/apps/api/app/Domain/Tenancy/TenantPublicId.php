<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;

/** Seven-character identifier: exactly five digits, one uppercase and one lowercase letter. */
final class TenantPublicId {
    public static function generate(): string {
        $characters = [];
        for ($i = 0; $i < 5; $i++) $characters[] = (string) random_int(0, 9);
        $characters[] = chr(random_int(65, 90));
        $characters[] = chr(random_int(97, 122));
        // Cryptographically secure Fisher-Yates shuffle: letter positions are unpredictable.
        for ($i = count($characters) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$characters[$i], $characters[$j]] = [$characters[$j], $characters[$i]];
        }
        return implode('', $characters);
    }
    public static function isValid(mixed $value): bool {
        return is_string($value)
            && preg_match('/^[0-9A-Za-z]{7}$/D', $value) === 1
            && preg_match_all('/[0-9]/', $value) === 5
            && preg_match_all('/[A-Z]/', $value) === 1
            && preg_match_all('/[a-z]/', $value) === 1;
    }
}
