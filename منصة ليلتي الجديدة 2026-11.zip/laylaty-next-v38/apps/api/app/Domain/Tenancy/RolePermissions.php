<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;
final class RolePermissions {
 private const MAP = [
  'owner'=>['bookings.read','bookings.write','bookings.confirm','contracts.write','payments.record','invoices.read','invoices.write','journals.write'],
  'manager'=>['bookings.read','bookings.write','bookings.confirm','contracts.write','invoices.read'],
  'booking_manager'=>['bookings.read','bookings.write','bookings.confirm','contracts.write'],
  'accountant'=>['bookings.read','payments.record','invoices.read','invoices.write','journals.write'],
  'viewer'=>['bookings.read']
 ];
 public static function allows(string $role,string $permission):bool {
  return in_array($permission,self::MAP[$role]??[],true);
 }
}
