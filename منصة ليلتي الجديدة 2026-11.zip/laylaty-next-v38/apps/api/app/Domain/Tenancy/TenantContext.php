<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;

use DomainException;

/** Request-local authorization context. No global/static tenant state. */
final class TenantContext {
    public function __construct(
        public readonly int $tenantId,
        public readonly int $userId,
        public readonly string $role,
        public readonly string $tenantType,
    ) {
        if ($tenantId < 1 || $userId < 1 || !AccessPolicy::validMembership($role)
            || !in_array($tenantType, ['store', 'hall'], true)) {
            throw new DomainException('Invalid tenant context');
        }
    }
    public function requireTenant(int $requestedTenantId): void {
        if (!AccessPolicy::matchesRouteTenant($requestedTenantId, $this->tenantId)) {
            throw new DomainException('Tenant mismatch');
        }
    }
    public function requireRole(array $allowedRoles): void {
        if (!in_array($this->role, $allowedRoles, true)) {
            throw new DomainException('Role denied');
        }
    }
    public function requireType(string $type): void {
        if ($this->tenantType !== $type) {
            throw new DomainException('Tenant type denied');
        }
    }
    public static function positiveId(mixed $value): int {
        if (!is_int($value) && !is_string($value)) throw new DomainException('Invalid identifier');
        $s=(string)$value;
        if (!preg_match('/^[1-9][0-9]*$/D', $s)) throw new DomainException('Invalid identifier');
        $id=filter_var($s,FILTER_VALIDATE_INT,['options'=>['min_range'=>1]]);
        if ($id === false) throw new DomainException('Invalid identifier');
        return $id;
    }
}
