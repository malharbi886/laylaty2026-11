<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;

use DomainException;

/** Validates foreign IDs before tenant-scoped queries. Never trust request-supplied tenant IDs. */
final class TenantScope {
    public static function requireResourceTenant(TenantContext $context, mixed $resourceTenantId): int {
        $id=TenantContext::positiveId($resourceTenantId);
        $context->requireTenant($id);
        return $id;
    }
    public static function requireCustomerOwner(mixed $authenticatedUserId, mixed $ownerId): int {
        $user=TenantContext::positiveId($authenticatedUserId);
        $owner=TenantContext::positiveId($ownerId);
        if (!AccessPolicy::belongsToCustomer($user,$owner)) throw new DomainException('Customer ownership denied');
        return $user;
    }
    public static function requireBranchInTenant(TenantContext $context, mixed $branchTenantId): void {
        self::requireResourceTenant($context,$branchTenantId);
    }
}
