<?php
declare(strict_types=1);
namespace App\Domain\Tenancy;

/** Fail closed: never infer authority from a URL tenant identifier alone. */
final class AccessPolicy {
    private const ROLES = ['owner', 'manager', 'booking_manager', 'accountant', 'viewer'];

    public static function validMembership(?string $role): bool {
        return $role !== null && in_array($role, self::ROLES, true);
    }

    public static function matchesRouteTenant(int $routeTenant, int $memberTenant): bool {
        return $routeTenant > 0 && $memberTenant > 0 && $routeTenant === $memberTenant;
    }

    public static function belongsToCustomer(int $authenticatedUserId, int $resourceOwnerId): bool {
        return $authenticatedUserId > 0 && $authenticatedUserId === $resourceOwnerId;
    }
}
