<?php
declare(strict_types=1);
namespace App\Domain\Bookings;
use DomainException;
final class SlotPolicy {
 public static function overlaps(string $startA,string $endA,string $startB,string $endB):bool {
  $a1=strtotime($startA);$a2=strtotime($endA);
  $b1=strtotime($startB);$b2=strtotime($endB);
  if($a1===false||$a2===false||$b1===false||$b2===false||$a1>=$a2||$b1>=$b2)
   throw new DomainException('Invalid booking interval');
  return $a1<$b2 && $a2>$b1;
 }
}
