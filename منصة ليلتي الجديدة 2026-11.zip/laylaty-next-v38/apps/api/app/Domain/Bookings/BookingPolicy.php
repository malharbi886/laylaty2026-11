<?php
namespace App\Domain\Bookings;
use App\Domain\Tenancy\TenantContext;

final class BookingPolicy
{
    public function __construct(private readonly TenantContext $tenant) {}
    public function canConfirm(array $booking, array $overlappingBookings): bool {
        $this->tenant->assertOwns($booking['tenant_id']);
        if ($booking['status'] !== 'pending') return false;
        foreach ($overlappingBookings as $other) {
            $this->tenant->assertOwns($other['tenant_id']);
            if ($other['id'] !== $booking['id'] && $other['hall_id'] === $booking['hall_id']
                && $other['slot_id'] === $booking['slot_id'] && $other['date'] === $booking['date']
                && in_array($other['status'], ['confirmed', 'held'], true)) return false;
        }
        return true;
    }
}
