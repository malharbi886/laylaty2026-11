<?php
declare(strict_types=1);
namespace App\Domain\Bookings;
use DomainException;
final class BookingStateMachine {
 private const ALLOWED = [
  'pending' => ['confirmed','cancelled'],
  'confirmed' => ['completed','cancelled'],
  'completed' => [],
  'cancelled' => []
 ];
 public static function transition(string $from,string $to): string {
  if(!in_array($to,self::ALLOWED[$from]??[],true)) throw new DomainException('Invalid booking status transition');
  return $to;
 }
}
