<?php
declare(strict_types=1);
namespace App\Domain\Inventory;
use DomainException;
final class StockMovement {
 public static function next(int $current,int $delta):int {
  if($current<0||$delta===0)throw new DomainException('Invalid stock adjustment');
  if($delta>0&&$current>PHP_INT_MAX-$delta)throw new DomainException('Stock overflow');
  $next=$current+$delta;
  if($next<0||$next>2147483647)throw new DomainException('Stock out of range');
  return $next;
 }
 public static function type(int $delta):string {return $delta>0?'receipt':'adjustment';}
}
