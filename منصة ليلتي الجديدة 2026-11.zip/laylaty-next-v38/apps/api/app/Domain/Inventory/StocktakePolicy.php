<?php
declare(strict_types=1);
namespace App\Domain\Inventory;
use DomainException;
final class StocktakePolicy {
 public static function variance(int $recorded,int $counted):int {
  if($recorded<0||$counted<0||$recorded>1000000000||$counted>1000000000)throw new DomainException('Invalid count');
  return $counted-$recorded;
 }
}
