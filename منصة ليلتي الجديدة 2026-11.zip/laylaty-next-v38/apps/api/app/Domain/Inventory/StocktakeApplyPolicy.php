<?php
declare(strict_types=1);
namespace App\Domain\Inventory;
use DomainException;
final class StocktakeApplyPolicy {
 public static function delta(int $recorded,int $current,int $counted):int {
  if($recorded<0||$current<0||$counted<0)throw new DomainException('Negative inventory');
  if($recorded!==$current)throw new DomainException('Stale count');
  return $counted-$current;
 }
}
