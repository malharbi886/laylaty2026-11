<?php
declare(strict_types=1);
namespace App\Domain\Inventory;
use DomainException;
final class TransferPolicy {
 public static function validate(int $source,int $destination,int $quantity):void {
  if($source<1||$destination<1||$source===$destination||$quantity<1||$quantity>1000000)
   throw new DomainException('Invalid transfer');
 }
 public static function move(int $available,int $destination,int $quantity):array {
  if($quantity<1)throw new DomainException('Invalid quantity');
  return [StockMovement::next($available,-$quantity),StockMovement::next($destination,$quantity)];
 }
}
