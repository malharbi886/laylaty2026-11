<?php
declare(strict_types=1);
namespace App\Domain\Payments;
use DomainException;
final class PaymentSubmissionPolicy {
 public static function available(int $totalHalalas,array $payments):int {
  if($totalHalalas<0)throw new DomainException('Negative booking total');
  $reserved=0;
  foreach($payments as $payment){
   $amount=$payment['amount_halalas']??null;$status=$payment['status']??null;
   if(!is_int($amount)||$amount<0)throw new DomainException('Invalid payment amount');
   if(in_array($status,['pending','approved'],true)){
    if($reserved>PHP_INT_MAX-$amount)throw new DomainException('Overflow');
    $reserved+=$amount;
   }
  }
  if($reserved>$totalHalalas)throw new DomainException('Overbooked payments');
  return $totalHalalas-$reserved;
 }
 public static function assertCanSubmit(int $totalHalalas,array $payments,int $newAmount):void {
  if($newAmount<=0||$newAmount>self::available($totalHalalas,$payments))
   throw new DomainException('Payment exceeds available balance');
 }
}
