<?php
declare(strict_types=1);
namespace App\Domain\Merchants;
use DomainException;
final class OrderWorkflow {
 private const NEXT=[
  'new'=>['confirmed','cancelled'],
  'confirmed'=>['in_production','cancelled'],
  'in_production'=>['ready','cancelled'],
  'ready'=>['delivered','cancelled'],
  'delivered'=>[], 'cancelled'=>[]
 ];
 public static function transition(string $from,string $to):string {
  if(!in_array($to,self::NEXT[$from]??[],true))throw new DomainException('Order transition not allowed');
  return $to;
 }
 public static function consumesStock(string $kind):bool {return $kind==='product';}
}
