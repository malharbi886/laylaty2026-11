<?php
declare(strict_types=1);
namespace App\Domain\Merchants;
use DomainException;
final class AppointmentPolicy {
 public static function assertWindow(string $start,string $end):void {
  $a=strtotime($start);$b=strtotime($end);
  if($a===false||$b===false||$a>=$b)throw new DomainException('Invalid appointment window');
 }
 public static function overlaps(string $aStart,string $aEnd,string $bStart,string $bEnd):bool {
  self::assertWindow($aStart,$aEnd);self::assertWindow($bStart,$bEnd);
  return strtotime($aStart)<strtotime($bEnd)&&strtotime($aEnd)>strtotime($bStart);
 }
}
