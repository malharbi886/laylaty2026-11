<?php
declare(strict_types=1);
namespace App\Domain\Merchants;
use DomainException;
final class MerchantPolicy {
 public static function requireStore(string $type):void {
  if($type!=='store')throw new DomainException('Store tenant required');
 }
 public static function orderTotal(array $lines):int {
  if(!$lines)throw new DomainException('Order lines required');
  $total=0;
  foreach($lines as $line){
   $q=$line['quantity']??null;$p=$line['unit_price_halalas']??null;
   if(!is_int($q)||$q<1||!is_int($p)||$p<0||$p>intdiv(PHP_INT_MAX,$q))
    throw new DomainException('Invalid line');
   $v=$q*$p;
   if($v>PHP_INT_MAX-$total)throw new DomainException('Overflow');
   $total+=$v;
  }
  return $total;
 }
}
