<?php
declare(strict_types=1);
namespace App\Domain\Merchants;
use DomainException;
final class PurchaseMath {
 public static function total(array $lines):int {
  if(!$lines)throw new DomainException('Empty purchase');
  $sum=0;
  foreach($lines as $l){
   $q=$l['quantity']??null;$p=$l['unit_cost_halalas']??null;
   if(!is_int($q)||$q<1||!is_int($p)||$p<0||$p>intdiv(PHP_INT_MAX,$q))throw new DomainException('Invalid purchase line');
   $line=$q*$p;
   if($line>PHP_INT_MAX-$sum)throw new DomainException('Purchase overflow');
   $sum+=$line;
  }
  return $sum;
 }
}
