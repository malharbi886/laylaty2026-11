<?php
declare(strict_types=1);
namespace App\Domain\Merchants;
use DomainException;
final class ReceiptPolicy {
 public static function receive(string $status):void {
  if($status!=='draft')throw new DomainException('Purchase already received or not receivable');
 }
 public static function nextQuantity(int $before,int $incoming):int {
  if($before<0||$incoming<1||$incoming>1000000||$before>2147483647-$incoming)
   throw new DomainException('Invalid receipt quantity');
  return $before+$incoming;
 }
}
