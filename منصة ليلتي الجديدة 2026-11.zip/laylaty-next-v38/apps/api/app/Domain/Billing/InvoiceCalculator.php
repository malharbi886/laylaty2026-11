<?php
declare(strict_types=1);
namespace App\Domain\Billing;
use DomainException;
final class InvoiceCalculator {
 public static function calculate(array $lines,int $vatBasisPoints):array {
  if($vatBasisPoints<0||$vatBasisPoints>10000)throw new DomainException('Invalid VAT rate');
  if(!$lines)throw new DomainException('Invoice requires lines');
  $subtotal=0;$vat=0;
  foreach($lines as $line){
   $qty=$line['quantity']??null;$unit=$line['unit_price_halalas']??null;
   if(!is_int($qty)||$qty<1||!is_int($unit)||$unit<0||$unit>100000000000)throw new DomainException('Invalid line');
   $amount=$qty*$unit;
   if($amount>PHP_INT_MAX-$subtotal)throw new DomainException('Invoice overflow');
   $subtotal+=$amount;
   $lineVat=intdiv($amount*$vatBasisPoints+5000,10000);
   if($lineVat>PHP_INT_MAX-$vat)throw new DomainException('VAT overflow');
   $vat+=$lineVat;
  }
  if($vat>PHP_INT_MAX-$subtotal)throw new DomainException('Total overflow');
  return ['subtotal_halalas'=>$subtotal,'vat_halalas'=>$vat,'total_halalas'=>$subtotal+$vat];
 }
}
