<?php
declare(strict_types=1);
namespace App\Http\Middleware;

use App\Domain\Tenancy\AccessPolicy;
use App\Domain\Tenancy\TenantContext;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\Response;

final class ResolveTenant {
    public function handle(Request $request, Closure $next): Response {
        $user = $request->user();
        // Fail closed if middleware is invoked outside the authenticated route group.
        if (!$user) abort(401);
        $raw = $request->route('tenant');
        if (!\App\Domain\Tenancy\TenantPublicId::isValid($raw)) abort(404);
        $tenantId = DB::table('tenants')->where('public_id', $raw)->value('id');
        if (!$tenantId) abort(404);
        $tenantId = (int) $tenantId;
        // Controllers historically accept numeric $tenant route parameters. After authentication,
        // replace the route parameter with the trusted internal ID for backwards compatibility.
        $request->route()->setParameter('tenant', $tenantId);

        // Check that the tenant exists and the authenticated user has an explicit valid membership.
        $membership = DB::table('tenant_memberships as m')
            ->join('tenants as t', 't.id', '=', 'm.tenant_id')
            ->where('m.tenant_id', $tenantId)
            ->where('m.user_id', $user->id)
            ->select('m.tenant_id', 'm.role', 't.type as tenant_type')
            ->first();
        if (!$membership || !AccessPolicy::matchesRouteTenant((int) $tenantId, (int) $membership->tenant_id)
            || !AccessPolicy::validMembership($membership->role)) abort(404);

        try {
            $context = new TenantContext((int) $tenantId, (int) $user->id, (string) $membership->role, (string) $membership->tenant_type);
        } catch (\DomainException $e) { abort(404); }
        $request->attributes->set('laylaty_context', $context);
        $request->attributes->set('laylaty_tenant_id', (int) $tenantId);
        $request->attributes->set('laylaty_role', $membership->role);
        $request->attributes->set('laylaty_tenant_type', $membership->tenant_type);
        return $next($request);
    }
}
