<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Merchants\OrderWorkflow;
use App\Domain\Audit\AuditRecorder;
use App\Domain\Audit\AuditDiff;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use DomainException;
final class MerchantOrderWorkflowController extends Controller {
 public function update(Request $request,int $tenant,int $order) {
  $role=$request->attributes->get('laylaty_role');
  if(!in_array($role,['owner','manager'],true))abort(403);
  $type=DB::table('tenants')->where('id',$tenant)->value('type');
  if($type!=='store')abort(403);
  $data=$request->validate(['status'=>'required|in:confirmed,in_production,ready,delivered,cancelled','reason'=>'required_if:status,cancelled|nullable|string|min:5|max:500']);
  return DB::transaction(function()use($request,$tenant,$order,$data){
   $row=DB::table('merchant_orders')->where('tenant_id',$tenant)->where('id',$order)->lockForUpdate()->first();
   if(!$row)abort(404);
   try{OrderWorkflow::transition($row->status,$data['status']);}
   catch(DomainException $e){throw ValidationException::withMessages(['status'=>$e->getMessage()]);}
   // Stock is consumed once at confirmation, and restored on cancellation after confirmation.
   if($data['status']==='confirmed'||$data['status']==='cancelled'&&$row->status!=='new') {
    $lines=DB::table('merchant_order_lines as l')->join('catalog_items as i',function($join){
      $join->on('i.id','=','l.catalog_item_id')->on('i.tenant_id','=','l.tenant_id');
     })->where('l.tenant_id',$tenant)->where('l.merchant_order_id',$order)
     ->where('i.kind','product')->select('l.catalog_item_id','l.quantity')->get();
    $quantities=[];
    foreach($lines as $line)$quantities[$line->catalog_item_id]=($quantities[$line->catalog_item_id]??0)+(int)$line->quantity;
    ksort($quantities,SORT_NUMERIC);
    foreach($quantities as $itemId=>$quantity){
     $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)
      ->where('branch_id',$row->branch_id)->where('item_id',$itemId)->lockForUpdate()->first();
     if(!$balance)throw ValidationException::withMessages(['inventory'=>'Stock balance missing']);
     if($data['status']==='confirmed'){
      if($balance->quantity<$quantity)throw ValidationException::withMessages(['inventory'=>'Insufficient stock']);
      $new=(int)$balance->quantity-$quantity;
     }else{$new=(int)$balance->quantity+$quantity;}
     DB::table('inventory_balances')->where('id',$balance->id)->where('tenant_id',$tenant)
      ->update(['quantity'=>$new,'updated_at'=>now()]);
    }
   }
   DB::table('merchant_orders')->where('tenant_id',$tenant)->where('id',$order)
    ->update(['status'=>$data['status'],'updated_at'=>now()]);
   $changes=AuditDiff::between(['status'=>$row->status],['status'=>$data['status']],['status']);
   // Record within the same transaction: failure to write audit rolls back the order and stock changes.
   AuditRecorder::record($request,$tenant,'merchant_order.status_changed','merchant_order',(string)$order,$changes,
    $data['status']==='cancelled' ? $data['reason'] : null);
   return response()->json(['id'=>$order,'status'=>$data['status']]);
  },3);
 }
}
