<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\POS\CashRefundPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PosRefundController extends Controller {
 public function refund(Request $r,int $tenant,int $shift,int $sale){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
  $data=$r->validate(['reason'=>'required|string|min:5|max:500']);
  return DB::transaction(function()use($r,$tenant,$shift,$sale,$data){
   $s=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('id',$shift)->lockForUpdate()->first();
   if(!$s)abort(404);
   $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)
    ->where('id',$sale)->lockForUpdate()->first();
   if(!$row)abort(404);
   $prior=DB::table('pos_cash_refunds')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
   if($prior&&$row->status==='refunded')return response()->json(['sale_id'=>$sale,'status'=>'refunded','replayed'=>true]);
   $receipt=DB::table('pos_cash_receipts')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
   try{CashRefundPolicy::authorize($row->status,$s->status,(int)($receipt->amount_halalas??0),$prior?1:0);}
   catch(DomainException $e){throw ValidationException::withMessages(['refund'=>$e->getMessage()]);}
   if((int)$receipt->amount_halalas!==(int)$row->total_halalas)
    throw ValidationException::withMessages(['refund'=>'Receipt mismatch']);
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$s->branch_id)->lockForUpdate()->first();
   if(!$branch)abort(404);
   $lines=DB::table('pos_sale_lines as l')->join('catalog_items as i',function($j){
    $j->on('i.id','=','l.item_id')->on('i.tenant_id','=','l.tenant_id');
   })->where('l.tenant_id',$tenant)->where('l.sale_id',$sale)->get(['l.item_id','l.quantity','i.kind']);
   $qtys=[];
   foreach($lines as $line)if($line->kind==='product'){
    $id=(int)$line->item_id;$q=(int)$line->quantity;
    if($q<1||$q>PHP_INT_MAX-($qtys[$id]??0))throw ValidationException::withMessages(['refund'=>'Invalid quantity']);
    $qtys[$id]=($qtys[$id]??0)+$q;
   }
   ksort($qtys,SORT_NUMERIC);
   foreach($qtys as $item=>$qty){
    $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$s->branch_id)
     ->where('item_id',$item)->lockForUpdate()->first();
    if(!$balance)throw ValidationException::withMessages(['refund'=>'Inventory balance missing']);
    $before=(int)$balance->quantity;
    if($qty>2147483647-$before)throw ValidationException::withMessages(['refund'=>'Inventory overflow']);
    DB::table('inventory_balances')->where('id',$balance->id)->where('tenant_id',$tenant)
     ->update(['quantity'=>$before+$qty,'updated_at'=>now()]);
    DB::table('inventory_movements')->insert(['tenant_id'=>$tenant,'branch_id'=>$s->branch_id,'item_id'=>$item,
     'reference'=>'POS-REFUND-'.$sale.'-'.$item,'kind'=>'pos_refund','delta'=>$qty,'quantity_before'=>$before,
     'quantity_after'=>$before+$qty,'actor_id'=>$r->user()->id,'reason'=>$data['reason'],
     'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('pos_cash_refunds')->insert(['tenant_id'=>$tenant,'sale_id'=>$sale,
    'amount_halalas'=>(int)$receipt->amount_halalas,'refunded_by'=>$r->user()->id,
    'reason'=>$data['reason'],'created_at'=>now(),'updated_at'=>now()]);
   DB::table('pos_sales')->where('tenant_id',$tenant)->where('id',$sale)
    ->update(['status'=>'refunded','updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'pos_sale.cash_refunded','resource_type'=>'pos_sale','resource_id'=>(string)$sale,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['sale_id'=>$sale,'status'=>'refunded','replayed'=>false]);
  },3);
 }
}
