<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Stores\StorefrontPolicy;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use DomainException;
final class StorefrontController extends Controller {
 public function show(string $slug){
  $store=DB::table('store_profiles')->where('slug',$slug)->where('status','published')->first();
  if(!$store)abort(404);
  $tenant=DB::table('tenants')->where('id',$store->tenant_id)->first();
  if(!$tenant||$tenant->type!=='store')abort(404);
  return response()->json(['store'=>['slug'=>$store->slug,'specialty_id'=>$store->specialty_id,'description'=>$store->description],
   'items'=>DB::table('catalog_items')->where('tenant_id',$store->tenant_id)->where('active',true)
    ->select('sku','name','kind','price_halalas')->orderBy('id')->paginate(24)]);
 }
 public function profile(Request $request,int $tenant){
  $this->guard($request,$tenant,false);
  return DB::table('store_profiles')->where('tenant_id',$tenant)->first()??response()->json(['message'=>'No profile'],404);
 }
 public function save(Request $request,int $tenant){
  $this->guard($request,$tenant,true);
  $data=$request->validate(['slug'=>'required|string|max:60','specialty_id'=>'required|string|max:64',
   'description'=>'nullable|string|max:5000']);
  try{$data['slug']=StorefrontPolicy::slug($data['slug']);}
  catch(DomainException $e){throw ValidationException::withMessages(['slug'=>$e->getMessage()]);}
  DB::transaction(function()use($request,$tenant,$data){
   DB::table('store_profiles')->updateOrInsert(['tenant_id'=>$tenant],
    [...$data,'status'=>'draft','updated_at'=>now()]);
  });
  return response()->json(['status'=>'draft']);
 }
 private function guard(Request $request,int $tenant,bool $write):void {
  $context=$request->attributes->get('laylaty_context');
  if (!$context instanceof \App\Domain\Tenancy\TenantContext) abort(403);
  try {$context->requireTenant($tenant);} catch (\DomainException $e) {abort(404);}
  $row=DB::table('tenants')->where('id',$tenant)->first();
  if(!$row)abort(404);
  if($row->type!=='store')abort(403);
  if(!in_array($request->attributes->get('laylaty_role'),$write?['owner','manager']:['owner','manager','accountant','viewer'],true))abort(403);
 }
}
