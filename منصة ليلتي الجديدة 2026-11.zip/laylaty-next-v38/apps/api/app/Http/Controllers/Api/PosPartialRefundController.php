<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\POS\PartialRefundPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PosPartialRefundController extends Controller {
 public function quote(Request $r,int $tenant,int $shift,int $sale){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
  $data=$r->validate(['lines'=>'required|array|min:1|max:100',
   'lines.*.line_id'=>'required|integer|min:1|distinct',
   'lines.*.quantity'=>'required|integer|min:1']);
  $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)
   ->where('id',$sale)->first();
  if(!$row)abort(404);
  if($row->status!=='completed')throw ValidationException::withMessages(['sale'=>'Only completed sales can be quoted']);
  if(DB::table('pos_cash_refunds')->where('tenant_id',$tenant)->where('sale_id',$sale)->exists())
   throw ValidationException::withMessages(['sale'=>'Already fully refunded']);
  $sold=DB::table('pos_sale_lines')->where('tenant_id',$tenant)->where('sale_id',$sale)
   ->get(['id','quantity','line_total_halalas'])->map(fn($l)=>[
    'line_id'=>(int)$l->id,'quantity'=>(int)$l->quantity,
    'line_total_halalas'=>(int)$l->line_total_halalas])->all();
  $requested=[];
  foreach($data['lines'] as $line)$requested[(int)$line['line_id']]=(int)$line['quantity'];
  // Existing drafts are NOT completed refunds and do not consume refundable quantity.
  // This endpoint deliberately never writes, pays out, or restocks.
  try{$quote=PartialRefundPolicy::calculate($sold,[],$requested);}
  catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
  return response()->json(['sale_id'=>$sale,'quote'=>$quote,
   'warning'=>'Estimate only: no refund, inventory movement or accounting entry was created']);
 }

 /** Records an immutable quote snapshot as a draft. No cash or inventory movement. */
 public function draft(Request $r,int $tenant,int $shift,int $sale){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
  $d=$r->validate([
   'request_key'=>'required|string|min:8|max:100',
   'reason'=>'required|string|min:3|max:500',
   'lines'=>'required|array|min:1|max:100',
   'lines.*.line_id'=>'required|integer|min:1|distinct',
   'lines.*.quantity'=>'required|integer|min:1',
  ]);
  return DB::transaction(function()use($r,$tenant,$shift,$sale,$d){
   $prior=DB::table('pos_partial_refund_requests')->where('tenant_id',$tenant)
    ->where('request_key',$d['request_key'])->first();
   if($prior)throw ValidationException::withMessages(['request_key'=>'Key already used; inspect the existing request']);
   $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)
    ->where('id',$sale)->lockForUpdate()->first();
   if(!$row)abort(404);
   if($row->status!=='completed')throw ValidationException::withMessages(['sale'=>'Only completed sales']);
   if(DB::table('pos_cash_refunds')->where('tenant_id',$tenant)->where('sale_id',$sale)->exists())
    throw ValidationException::withMessages(['sale'=>'Sale already fully refunded']);
   $sold=DB::table('pos_sale_lines')->where('tenant_id',$tenant)->where('sale_id',$sale)
    ->get(['id','quantity','line_total_halalas'])->map(fn($l)=>[
     'line_id'=>(int)$l->id,'quantity'=>(int)$l->quantity,
     'line_total_halalas'=>(int)$l->line_total_halalas])->all();
   $requested=[];
   foreach($d['lines'] as $line)$requested[(int)$line['line_id']]=(int)$line['quantity'];
   // Drafts are NOT settlements. No quantity is consumed until a future verified settlement workflow.
   try{$quote=PartialRefundPolicy::calculate($sold,[],$requested);}
   catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
   $id=DB::table('pos_partial_refund_requests')->insertGetId([
    'tenant_id'=>$tenant,'sale_id'=>$sale,'request_key'=>$d['request_key'],
    'status'=>'draft','quoted_total_halalas'=>$quote['total_halalas'],
    'reason'=>$d['reason'],'requested_by'=>$r->user()->id,
    'created_at'=>now(),'updated_at'=>now()]);
   foreach($quote['lines'] as $line)DB::table('pos_partial_refund_request_lines')->insert([
    'tenant_id'=>$tenant,'request_id'=>$id,'sale_line_id'=>$line['line_id'],
    'quantity'=>$line['quantity'],'quoted_amount_halalas'=>$line['amount_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft','quote'=>$quote,
    'warning'=>'No refund issued and no inventory was changed'],201);
  });
 }
}
