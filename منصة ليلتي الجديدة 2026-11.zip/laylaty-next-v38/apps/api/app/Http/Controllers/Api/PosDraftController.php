<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Merchants\MerchantPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
final class PosDraftController extends Controller {
 private function access(Request $r,int $tenant):void {
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
 }
 public function cancel(Request $r,int $tenant,int $shift,int $sale){
  $this->access($r,$tenant);
  return DB::transaction(function()use($r,$tenant,$shift,$sale){
   $shiftRow=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('id',$shift)->lockForUpdate()->first();
   if(!$shiftRow||$shiftRow->status!=='open')throw ValidationException::withMessages(['shift'=>'Open shift required']);
   $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)->where('id',$sale)->lockForUpdate()->first();
   if(!$row)abort(404);
   try{$status=\App\Domain\POS\SaleDraftPolicy::cancel($row->status);}
   catch(DomainException $e){throw ValidationException::withMessages(['sale'=>$e->getMessage()]);}
   DB::table('pos_sales')->where('tenant_id',$tenant)->where('id',$sale)->update(['status'=>$status,'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'pos_sale.draft_cancelled','resource_type'=>'pos_sale','resource_id'=>(string)$sale,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$sale,'status'=>$status,'note'=>'No payment or inventory movement']);
  },3);
 }
 public function store(Request $r,int $tenant,int $shift){
  $this->access($r,$tenant);
  $d=$r->validate(['lines'=>'required|array|min:1|max:100',
   'lines.*.item_id'=>'required|integer|min:1','lines.*.quantity'=>'required|integer|min:1|max:100000']);
  return DB::transaction(function()use($r,$tenant,$shift,$d){
   $s=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('id',$shift)->lockForUpdate()->first();
   if(!$s||$s->status!=='open')throw ValidationException::withMessages(['shift'=>'Open shift required']);
   $ids=array_unique(array_column($d['lines'],'item_id'));
   $items=DB::table('catalog_items')->where('tenant_id',$tenant)->where('active',true)->whereIn('id',$ids)->get()->keyBy('id');
   if($items->count()!==count($ids))throw ValidationException::withMessages(['lines'=>'Invalid item']);
   $lines=[];
   foreach($d['lines'] as $line){
    $item=$items->get($line['item_id']);
    $lines[]=['item_id'=>$item->id,'name_snapshot'=>$item->name,'quantity'=>(int)$line['quantity'],
     'unit_price_halalas'=>(int)$item->price_halalas];
   }
   try{$total=MerchantPolicy::orderTotal($lines);}
   catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
   $id=DB::table('pos_sales')->insertGetId(['tenant_id'=>$tenant,'shift_id'=>$shift,
    'reference'=>'LY-POS-'.Str::upper((string)Str::ulid()),'status'=>'draft','total_halalas'=>$total,
    'created_at'=>now(),'updated_at'=>now()]);
   foreach($lines as $line)DB::table('pos_sale_lines')->insert(['tenant_id'=>$tenant,'sale_id'=>$id,
    ...$line,'line_total_halalas'=>$line['quantity']*$line['unit_price_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'pos_sale.draft_created','resource_type'=>'pos_sale','resource_id'=>(string)$id,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft','total_halalas'=>$total,'note'=>'Not charged or settled'],201);
  },3);
 }
}
