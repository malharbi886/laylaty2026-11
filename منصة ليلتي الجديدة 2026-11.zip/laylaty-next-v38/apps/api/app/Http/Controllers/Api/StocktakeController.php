<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Inventory\StocktakePolicy;
use App\Domain\Inventory\StocktakeApplyPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class StocktakeController extends Controller {
 private function access(Request $r,int $tenant,bool $write=false):void {
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),$write?['owner','manager']:['owner','manager','accountant','viewer'],true))abort(403);
 }
 public function index(Request $r,int $tenant){
  $this->access($r,$tenant);return DB::table('store_stocktakes')->where('tenant_id',$tenant)->orderByDesc('id')->paginate(30);
 }
 public function show(Request $r,int $tenant,int $stocktake){
  $this->access($r,$tenant);$row=DB::table('store_stocktakes')->where('tenant_id',$tenant)->where('id',$stocktake)->first();
  if(!$row)abort(404);
  return response()->json(['stocktake'=>$row,'lines'=>DB::table('store_stocktake_lines')->where('tenant_id',$tenant)->where('stocktake_id',$stocktake)->get()]);
 }
 public function store(Request $r,int $tenant){
  $this->access($r,$tenant,true);
  $d=$r->validate(['branch_id'=>'required|integer|min:1','reference'=>'required|string|max:100',
   'lines'=>'required|array|min:1|max:200','lines.*.item_id'=>'required|integer|min:1',
   'lines.*.counted_quantity'=>'required|integer|min:0|max:1000000000']);
  $ids=array_column($d['lines'],'item_id');
  if(count($ids)!==count(array_unique($ids)))throw ValidationException::withMessages(['lines'=>'Duplicate item']);
  return DB::transaction(function()use($r,$tenant,$d){
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$d['branch_id'])->lockForUpdate()->first();
   if(!$branch)abort(404);
   $id=DB::table('store_stocktakes')->insertGetId(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'reference'=>$d['reference'],'status'=>'draft','created_by'=>$r->user()->id,'created_at'=>now(),'updated_at'=>now()]);
   foreach($d['lines'] as $line){
    $item=DB::table('catalog_items')->where('tenant_id',$tenant)->where('id',$line['item_id'])->where('kind','product')->first();
    if(!$item)throw ValidationException::withMessages(['lines'=>'Product not in store']);
    $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$d['branch_id'])
     ->where('item_id',$line['item_id'])->lockForUpdate()->first();
    $recorded=(int)($balance->quantity??0);$counted=(int)$line['counted_quantity'];
    $variance=StocktakePolicy::variance($recorded,$counted);
    DB::table('store_stocktake_lines')->insert(['tenant_id'=>$tenant,'stocktake_id'=>$id,'item_id'=>$line['item_id'],
     'recorded_quantity'=>$recorded,'counted_quantity'=>$counted,'variance'=>$variance,'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'stocktake.draft_created','resource_type'=>'stocktake','resource_id'=>(string)$id,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft','note'=>'No inventory was changed'],201);
  },3);
 }

 public function apply(Request $r,int $tenant,int $stocktake){
  $this->access($r,$tenant,true);
  return DB::transaction(function()use($r,$tenant,$stocktake){
   $draft=DB::table('store_stocktakes')->where('tenant_id',$tenant)->where('id',$stocktake)->first();
   if(!$draft)abort(404);
   // The branch lock serializes stocktakes with ordinary adjustments and transfers.
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$draft->branch_id)->lockForUpdate()->first();
   if(!$branch)abort(404);
   $draft=DB::table('store_stocktakes')->where('tenant_id',$tenant)->where('id',$stocktake)->lockForUpdate()->first();
   if($draft->status==='applied')return response()->json(['id'=>$stocktake,'status'=>'applied','replayed'=>true]);
   if($draft->status!=='draft')throw ValidationException::withMessages(['stocktake'=>'Not a draft']);
   $lines=DB::table('store_stocktake_lines')->where('tenant_id',$tenant)->where('stocktake_id',$stocktake)->orderBy('item_id')->get();
   if($lines->isEmpty())throw ValidationException::withMessages(['stocktake'=>'Empty stocktake']);
   // Reject stale counts; never silently overwrite sales or transfers after the count.
   foreach($lines as $line){
    $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$draft->branch_id)
     ->where('item_id',$line->item_id)->lockForUpdate()->first();
    $before=(int)($balance->quantity??0);
    $after=(int)$line->counted_quantity;
    try{$delta=StocktakeApplyPolicy::delta((int)$line->recorded_quantity,$before,$after);}
    catch(DomainException $e){throw ValidationException::withMessages(['stocktake'=>$e->getMessage()]);}
    if($delta===0)continue;
    if($balance){DB::table('inventory_balances')->where('tenant_id',$tenant)->where('id',$balance->id)
     ->update(['quantity'=>$after,'updated_at'=>now()]);}
    else {DB::table('inventory_balances')->insert(['tenant_id'=>$tenant,'branch_id'=>$draft->branch_id,
     'item_id'=>$line->item_id,'quantity'=>$after,'created_at'=>now(),'updated_at'=>now()]);}
    DB::table('inventory_movements')->insert(['tenant_id'=>$tenant,'branch_id'=>$draft->branch_id,
     'item_id'=>$line->item_id,'reference'=>'STOCKTAKE-'.$stocktake.'-'.$line->item_id,
     'kind'=>'stocktake','delta'=>$delta,'quantity_before'=>$before,'quantity_after'=>$after,
     'actor_id'=>$r->user()->id,'reason'=>'Approved physical stocktake '.$draft->reference,
     'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('store_stocktakes')->where('tenant_id',$tenant)->where('id',$stocktake)
    ->update(['status'=>'applied','updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'stocktake.applied','resource_type'=>'stocktake','resource_id'=>(string)$stocktake,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$stocktake,'status'=>'applied','replayed'=>false]);
  },3);
 }

}
