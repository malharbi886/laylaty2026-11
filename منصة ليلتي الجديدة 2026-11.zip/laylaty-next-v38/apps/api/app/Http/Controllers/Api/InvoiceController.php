<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use App\Domain\Billing\InvoiceCalculator;
use DomainException;
final class InvoiceController extends Controller {
 public function index(Request $request,int $tenant){
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'invoices.read'))abort(403);
  return DB::table('invoices')->where('tenant_id',$tenant)->orderByDesc('id')->paginate(25);
 }
 public function store(Request $request,int $tenant){
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'invoices.write'))abort(403);
  $data=$request->validate(['booking_id'=>'nullable|integer','vat_basis_points'=>'required|integer|min:0|max:10000',
   'lines'=>'required|array|min:1|max:100','lines.*.description'=>'required|string|max:255',
   'lines.*.quantity'=>'required|integer|min:1|max:100000','lines.*.unit_price_halalas'=>'required|integer|min:0|max:100000000000']);
  try{$totals=InvoiceCalculator::calculate($data['lines'],$data['vat_basis_points']);}
  catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
  return DB::transaction(function()use($request,$tenant,$data,$totals){
   if(isset($data['booking_id'])&&!DB::table('bookings')->where('tenant_id',$tenant)->where('id',$data['booking_id'])->exists())abort(404);
   $id=DB::table('invoices')->insertGetId(['tenant_id'=>$tenant,'booking_id'=>$data['booking_id']??null,
    'invoice_number'=>'DRAFT-'.Str::upper((string)Str::ulid()),'status'=>'draft',...$totals,'created_at'=>now(),'updated_at'=>now()]);
   foreach($data['lines'] as $line){
    $amount=$line['quantity']*$line['unit_price_halalas'];
    $vat=intdiv($amount*$data['vat_basis_points']+5000,10000);
    DB::table('invoice_lines')->insert(['tenant_id'=>$tenant,'invoice_id'=>$id,'description'=>$line['description'],
     'quantity'=>$line['quantity'],'unit_price_halalas'=>$line['unit_price_halalas'],
     'subtotal_halalas'=>$amount,'vat_halalas'=>$vat,'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'invoice.draft_created','resource_type'=>'invoice','resource_id'=>(string)$id,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft',...$totals],201);
  });
 }
}
