<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
final class CustomerEventController extends Controller {
 public function index(Request $request){return DB::table('customer_events')->where('customer_id',$request->user()->id)->orderBy('event_date')->paginate(25);}
 public function store(Request $request){
  $data=$request->validate(['title'=>'required|string|max:180','occasion_type'=>'required|string|max:80',
   'event_date'=>'required|date','city'=>'required|string|max:120','location_text'=>'nullable|string|max:500',
   'budget_halalas'=>'nullable|integer|min:0']);
  $id=DB::table('customer_events')->insertGetId([...$data,'customer_id'=>$request->user()->id,'created_at'=>now(),'updated_at'=>now()]);
  return response()->json(['id'=>$id],201);
 }
 public function tasks(Request $request,int $event){
  if(!DB::table('customer_events')->where('id',$event)->where('customer_id',$request->user()->id)->exists())abort(404);
  return DB::table('event_tasks')->where('event_id',$event)->whereExists(function($query)use($request){$query->selectRaw('1')->from('customer_events')->whereColumn('customer_events.id','event_tasks.event_id')->where('customer_events.customer_id',$request->user()->id);})->orderBy('sort_order')->get();
 }
 public function updateTask(Request $request,int $event,int $task){
  $data=$request->validate(['status'=>'required|in:in_progress,done,cancelled']);
  return DB::transaction(function()use($request,$event,$task,$data){
   $owner=DB::table('customer_events')->where('id',$event)->where('customer_id',$request->user()->id)->lockForUpdate()->first();
   if(!$owner)abort(404);
   $row=DB::table('event_tasks')->where('id',$task)->where('event_id',$event)->lockForUpdate()->first();
   if(!$row)abort(404);
   try{\App\Domain\Stores\StorefrontPolicy::taskStatus($row->status,$data['status']);}
   catch(\DomainException $e){return response()->json(['error'=>$e->getMessage()],422);}
   DB::table('event_tasks')->where('id',$task)->where('event_id',$event)->update(['status'=>$data['status'],'updated_at'=>now()]);
   return response()->json(['id'=>$task,'status'=>$data['status']]);
  });
 }
 public function addTask(Request $request,int $event){
  $data=$request->validate(['title'=>'required|string|max:200','specialty_code'=>'nullable|string|max:80','sort_order'=>'nullable|integer|min:0']);
  return DB::transaction(function()use($request,$event,$data){
   // Lock the parent event and verify ownership inside the same transaction as the insert.
   $owned=DB::table('customer_events')->where('id',$event)
    ->where('customer_id',$request->user()->id)->lockForUpdate()->first();
   if(!$owned)abort(404);
   $id=DB::table('event_tasks')->insertGetId([...$data,'event_id'=>$event,
    'status'=>'todo','created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id],201);
  });
 }
}
