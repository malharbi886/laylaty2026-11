<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use App\Domain\Contracts\ContractMath;
final class ContractController extends Controller {
 private function canEdit(Request $request):void {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'contracts.write')) abort(403);
 }
 public function index(Request $request,int $tenant,int $booking) {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'bookings.read')) abort(403);
  $exists=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)->exists();
  if(!$exists) abort(404);
  return DB::table('booking_contracts')->where('tenant_id',$tenant)->where('booking_id',$booking)
   ->orderByDesc('version')->get();
 }
 public function store(Request $request,int $tenant,int $booking) {
  $this->canEdit($request);
  $data=$request->validate([
   'terms_snapshot'=>'required|array',
   'services'=>'present|array|max:100',
   'services.*.name'=>'required|string|max:200',
   'services.*.quantity'=>'required|integer|min:1|max:100000',
   'services.*.unit_price_halalas'=>'required|integer|min:0|max:100000000000'
  ]);
  $lines=array_map(fn($x)=>['quantity'=>(int)$x['quantity'],
   'unit_price_halalas'=>(int)$x['unit_price_halalas']],$data['services']);
  ContractMath::servicesTotal($lines);
  return DB::transaction(function()use($request,$tenant,$booking,$data){
   $book=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)
    ->lockForUpdate()->first();
   if(!$book) abort(404);
   $version=(int)DB::table('booking_contracts')->where('tenant_id',$tenant)
    ->where('booking_id',$booking)->max('version')+1;
   $id=DB::table('booking_contracts')->insertGetId([
    'tenant_id'=>$tenant,'booking_id'=>$booking,'version'=>$version,
    'status'=>'draft','terms_snapshot'=>json_encode($data['terms_snapshot'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR),
    'created_at'=>now(),'updated_at'=>now()]);
   foreach($data['services'] as $line) {
    DB::table('contract_service_lines')->insert([
     'tenant_id'=>$tenant,'contract_id'=>$id,'name'=>$line['name'],
     'quantity'=>$line['quantity'],'unit_price_halalas'=>$line['unit_price_halalas'],
     'line_total_halalas'=>$line['quantity']*$line['unit_price_halalas'],
     'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('audit_events')->insert([
    'tenant_id'=>$tenant,'actor_id'=>$request->user()->id,'event'=>'contract.draft_created',
    'resource_type'=>'booking_contract','resource_id'=>(string)$id,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'version'=>$version,'status'=>'draft'],201);
  });
 }
 public function show(Request $request,int $tenant,int $booking,int $contract) {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'bookings.read')) abort(403);
  $row=DB::table('booking_contracts')->where('tenant_id',$tenant)->where('booking_id',$booking)
   ->where('id',$contract)->first();
  if(!$row) abort(404);
  $services=DB::table('contract_service_lines')->where('tenant_id',$tenant)->where('contract_id',$contract)->get();
  return response()->json(['contract'=>$row,'services'=>$services]);
 }
 public function approve(Request $request,int $tenant,int $booking,int $contract) {
  $this->canEdit($request);
  return DB::transaction(function()use($request,$tenant,$booking,$contract){
   $row=DB::table('booking_contracts')->where('tenant_id',$tenant)
    ->where('booking_id',$booking)->where('id',$contract)->lockForUpdate()->first();
   if(!$row) abort(404);
   try{$status=\App\Domain\Contracts\ContractStatus::approve($row->status);}
   catch(\DomainException $e){throw ValidationException::withMessages(['status'=>$e->getMessage()]);}
   $lines=DB::table('contract_service_lines')->where('tenant_id',$tenant)
    ->where('contract_id',$contract)->get();
   $total=\App\Domain\Contracts\ContractMath::servicesTotal(
    $lines->map(fn($l)=>['quantity'=>(int)$l->quantity,'unit_price_halalas'=>(int)$l->unit_price_halalas])->all()
   );
   DB::table('booking_contracts')->where('tenant_id',$tenant)->where('id',$contract)
    ->update(['status'=>$status,'approved_by'=>$request->user()->id,
      'approved_at'=>now(),'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'contract.approved','resource_type'=>'booking_contract',
    'resource_id'=>(string)$contract,'details'=>json_encode(['services_total_halalas'=>$total]),
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$contract,'status'=>$status,'services_total_halalas'=>$total]);
  });
 }

}
