<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Merchants\PurchaseMath;
use App\Domain\Merchants\AppointmentPolicy;
use App\Domain\POS\ShiftCalculator;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
final class StoreOperationsController extends Controller {
 private function access(Request $r,int $tenant,bool $write=true):void {
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  $roles=$write?['owner','manager']:['owner','manager','accountant','viewer'];
  if(!in_array($r->attributes->get('laylaty_role'),$roles,true))abort(403);
 }
 private function branch(int $tenant,int $branch):void {
  if(!DB::table('branches')->where('tenant_id',$tenant)->where('id',$branch)->exists())abort(404);
 }
 public function purchases(Request $r,int $tenant){
  $this->access($r,$tenant,false);
  return DB::table('store_purchase_orders')->where('tenant_id',$tenant)->orderByDesc('id')->paginate(30);
 }
 public function createPurchase(Request $r,int $tenant){
  $this->access($r,$tenant);
  $d=$r->validate(['branch_id'=>'required|integer|min:1','supplier_id'=>'required|integer|min:1',
   'reference'=>'required|string|max:100','lines'=>'required|array|min:1|max:100',
   'lines.*.item_id'=>'required|integer|min:1','lines.*.quantity'=>'required|integer|min:1|max:100000',
   'lines.*.unit_cost_halalas'=>'required|integer|min:0|max:100000000000']);
  return DB::transaction(function()use($tenant,$d){
   $this->branch($tenant,(int)$d['branch_id']);
   if(!DB::table('store_suppliers')->where('tenant_id',$tenant)->where('id',$d['supplier_id'])->exists())abort(404);
   $ids=array_unique(array_column($d['lines'],'item_id'));
   $items=DB::table('catalog_items')->where('tenant_id',$tenant)->where('kind','product')->whereIn('id',$ids)->pluck('id')->all();
   if(count($items)!==count($ids))throw ValidationException::withMessages(['lines'=>'Products must belong to store']);
   try{$total=PurchaseMath::total($d['lines']);}catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
   $id=DB::table('store_purchase_orders')->insertGetId(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'supplier_id'=>$d['supplier_id'],'reference'=>$d['reference'],'status'=>'draft',
    'total_halalas'=>$total,'created_at'=>now(),'updated_at'=>now()]);
   foreach($d['lines'] as $line)DB::table('store_purchase_lines')->insert(['tenant_id'=>$tenant,
    'purchase_id'=>$id,'item_id'=>$line['item_id'],'quantity'=>$line['quantity'],
    'unit_cost_halalas'=>$line['unit_cost_halalas'],
    'line_total_halalas'=>$line['quantity']*$line['unit_cost_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft','total_halalas'=>$total],201);
  },3);
 }
 public function appointments(Request $r,int $tenant){
  $this->access($r,$tenant,false);
  $d=$r->validate(['branch_id'=>'required|integer|min:1']);$this->branch($tenant,(int)$d['branch_id']);
  return DB::table('store_appointments')->where('tenant_id',$tenant)->where('branch_id',$d['branch_id'])->orderBy('starts_at')->paginate(30);
 }
 public function bookAppointment(Request $r,int $tenant){
  $this->access($r,$tenant);
  $d=$r->validate(['branch_id'=>'required|integer|min:1','item_id'=>'required|integer|min:1',
   'resource_key'=>'required|string|max:120','starts_at'=>'required|date','ends_at'=>'required|date|after:starts_at']);
  return DB::transaction(function()use($tenant,$d){
   // Serialize all reservations for this branch, including when no appointments yet exist.
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$d['branch_id'])->lockForUpdate()->first();
   if(!$branch)abort(404);
   if(!DB::table('catalog_items')->where('tenant_id',$tenant)->where('id',$d['item_id'])
    ->whereIn('kind',['service','rental'])->where('active',true)->exists())abort(404);
   $collision=DB::table('store_appointments')->where('tenant_id',$tenant)->where('branch_id',$d['branch_id'])
    ->where('resource_key',$d['resource_key'])->where('status','confirmed')
    ->where('starts_at','<',$d['ends_at'])->where('ends_at','>',$d['starts_at'])->exists();
   if($collision)throw ValidationException::withMessages(['starts_at'=>'Resource already booked']);
   $id=DB::table('store_appointments')->insertGetId([...$d,'tenant_id'=>$tenant,
    'status'=>'confirmed','created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'confirmed'],201);
  },3);
 }
 public function openShift(Request $r,int $tenant){
  $this->access($r,$tenant);
  $d=$r->validate(['branch_id'=>'required|integer|min:1','opening_cash_halalas'=>'required|integer|min:0|max:100000000000']);
  return DB::transaction(function()use($r,$tenant,$d){
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$d['branch_id'])->lockForUpdate()->first();
   if(!$branch)abort(404);
   if(DB::table('pos_shifts')->where('tenant_id',$tenant)->where('branch_id',$d['branch_id'])->where('status','open')->exists())
    throw ValidationException::withMessages(['branch_id'=>'An open shift already exists']);
   $id=DB::table('pos_shifts')->insertGetId(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'opened_by'=>$r->user()->id,'status'=>'open','opening_cash_halalas'=>$d['opening_cash_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'open'],201);
  },3);
 }
 public function closeShift(Request $r,int $tenant,int $shift){
  $this->access($r,$tenant);
  $d=$r->validate(['counted_cash_halalas'=>'required|integer|min:0|max:100000000000']);
  return DB::transaction(function()use($r,$tenant,$shift,$d){
   $row=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('id',$shift)->lockForUpdate()->first();
   if(!$row)abort(404);
   if($row->status!=='open')throw ValidationException::withMessages(['shift'=>'Already closed']);
   $sales=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)->get();
   foreach($sales as $sale){
    if(!in_array($sale->status,['cancelled','completed','refunded'],true))
     throw ValidationException::withMessages(['shift'=>'Unsettled sales exist']);
   }
   $receipts=DB::table('pos_cash_receipts as r')->join('pos_sales as s',function($j){
    $j->on('s.id','=','r.sale_id')->on('s.tenant_id','=','r.tenant_id');
   })->where('r.tenant_id',$tenant)->where('s.shift_id',$shift)->get(['r.amount_halalas','r.sale_id']);
   $completed=array_filter($sales->all(),fn($sale)=>in_array($sale->status,['completed','refunded'],true));
   if(count($completed)!==$receipts->count())
    throw ValidationException::withMessages(['shift'=>'Cash receipt reconciliation failed']);
   $cashSales=0;
   foreach($receipts as $receipt){
    if((int)$receipt->amount_halalas>PHP_INT_MAX-$cashSales)
     throw ValidationException::withMessages(['shift'=>'Cash total overflow']);
    $cashSales+=(int)$receipt->amount_halalas;
   }
   $refundRows=DB::table('pos_cash_refunds as f')->join('pos_sales as s',function($j){
    $j->on('s.id','=','f.sale_id')->on('s.tenant_id','=','f.tenant_id');
   })->where('f.tenant_id',$tenant)->where('s.shift_id',$shift)->get(['f.amount_halalas','s.status']);
   $refundTotal=0;
   foreach($refundRows as $refund){
    if($refund->status!=='refunded'||(int)$refund->amount_halalas>PHP_INT_MAX-$refundTotal)
     throw ValidationException::withMessages(['shift'=>'Refund reconciliation failed']);
    $refundTotal+=(int)$refund->amount_halalas;
   }
   $expected=\App\Domain\POS\CashRefundPolicy::expectedCash((int)$row->opening_cash_halalas,$cashSales,$refundTotal);
   $diff=(int)$d['counted_cash_halalas']-$expected;
   DB::table('pos_shifts')->where('id',$shift)->where('tenant_id',$tenant)->update([
    'status'=>'closed','closed_by'=>$r->user()->id,'closed_at'=>now(),
    'counted_cash_halalas'=>$d['counted_cash_halalas'],'closing_difference_halalas'=>$diff,'updated_at'=>now()]);
   return response()->json(['id'=>$shift,'status'=>'closed','difference_halalas'=>$diff]);
  },3);
 }
}
