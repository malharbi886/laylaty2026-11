<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;

use App\Domain\Audit\AuditAccess;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

final class TenantAuditController extends Controller {
    public function index(Request $request, int $tenant) {
        if (!AuditAccess::canReadTenantLog((string) $request->attributes->get('laylaty_role'))) abort(403);
        $filter = $request->validate([
            'event' => 'sometimes|string|max:100',
            'actor_id' => 'sometimes|integer|min:1',
            'resource_type' => 'sometimes|string|max:100',
            'from' => 'sometimes|date',
            'to' => 'sometimes|date|after_or_equal:from',
        ]);
        $q = DB::table('audit_events')->where('tenant_id', $tenant);
        foreach (['event', 'actor_id', 'resource_type'] as $key) {
            if (isset($filter[$key])) $q->where($key, $filter[$key]);
        }
        if (isset($filter['from'])) $q->where('created_at', '>=', $filter['from']);
        if (isset($filter['to'])) $q->where('created_at', '<=', $filter['to']);
        return $q->orderByDesc('id')->paginate(30);
    }
}
