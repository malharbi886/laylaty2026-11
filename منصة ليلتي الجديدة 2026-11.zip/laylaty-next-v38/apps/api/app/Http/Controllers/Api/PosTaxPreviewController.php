<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Accounting\PosTaxJournalPreview;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PosTaxPreviewController extends Controller {
 public function preview(Request $r,int $tenant,int $sale){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','accountant'],true))abort(403);
  $d=$r->validate(['vat_basis_points'=>'required|integer|min:0|max:10000',
   'cash_account_id'=>'required|integer|min:1','revenue_account_id'=>'required|integer|min:1',
   'vat_account_id'=>'required|integer|min:1']);
  $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('id',$sale)->first();
  if(!$row)abort(404);
  $receipt=DB::table('pos_cash_receipts')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
  if(!$receipt||$row->status!=='completed')
   throw ValidationException::withMessages(['sale'=>'Unrefunded completed cash sale required']);
  $ids=[(int)$d['cash_account_id'],(int)$d['revenue_account_id'],(int)$d['vat_account_id']];
  if(DB::table('ledger_accounts')->where('tenant_id',$tenant)->where('active',true)->whereIn('id',array_unique($ids))->count()!==3)
   throw ValidationException::withMessages(['accounts'=>'Three active tenant accounts required']);
  try{$result=PosTaxJournalPreview::build((int)$receipt->amount_halalas,(int)$d['vat_basis_points'],...$ids);}
  catch(DomainException $e){throw ValidationException::withMessages(['preview'=>$e->getMessage()]);}
  return response()->json($result);
 }
}
