<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use App\Domain\Accounting\JournalValidator;
use DomainException;
use Illuminate\Validation\ValidationException;
final class JournalController extends Controller {
 private function authorizeAccounting(Request $request):void {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'journals.write')) abort(403);
 }
 public function store(Request $request,int $tenant) {
  $this->authorizeAccounting($request);
  $data=$request->validate([
   'entry_date'=>'required|date','description'=>'nullable|string|max:2000',
   'lines'=>'required|array|min:2|max:100',
   'lines.*.ledger_account_id'=>'required|integer',
   'lines.*.debit_halalas'=>'required|integer|min:0',
   'lines.*.credit_halalas'=>'required|integer|min:0'
  ]);
  try {JournalValidator::validate($data['lines']);}
  catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
  return DB::transaction(function()use($request,$tenant,$data){
   $accountIds=array_unique(array_column($data['lines'],'ledger_account_id'));
   $found=DB::table('ledger_accounts')->where('tenant_id',$tenant)->where('active',true)
    ->whereIn('id',$accountIds)->count();
   if($found!==count($accountIds)) throw ValidationException::withMessages(['lines'=>'Invalid ledger account']);
   $id=DB::table('journal_entries')->insertGetId([
    'tenant_id'=>$tenant,'reference'=>'JE-'.Str::upper((string)Str::ulid()),
    'status'=>'draft','entry_date'=>$data['entry_date'],
    'description'=>$data['description']??null,'created_by'=>$request->user()->id,
    'created_at'=>now(),'updated_at'=>now()]);
   foreach($data['lines'] as $line)DB::table('journal_lines')->insert([
    'tenant_id'=>$tenant,'journal_entry_id'=>$id,'ledger_account_id'=>$line['ledger_account_id'],
    'debit_halalas'=>$line['debit_halalas'],'credit_halalas'=>$line['credit_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'draft'],201);
  });
 }
 public function show(Request $request,int $tenant,int $entry) {
  $this->authorizeAccounting($request);
  $row=DB::table('journal_entries')->where('tenant_id',$tenant)->where('id',$entry)->first();
  if(!$row) abort(404);
  return response()->json(['entry'=>$row,'lines'=>DB::table('journal_lines')
   ->where('tenant_id',$tenant)->where('journal_entry_id',$entry)->get()]);
 }
 public function post(Request $request,int $tenant,int $entry) {
  $this->authorizeAccounting($request);
  return DB::transaction(function()use($request,$tenant,$entry){
   $row=DB::table('journal_entries')->where('tenant_id',$tenant)
    ->where('id',$entry)->lockForUpdate()->first();
   if(!$row) abort(404);
   try{\App\Domain\Accounting\JournalStatus::post($row->status);}
   catch(\DomainException $e){throw ValidationException::withMessages(['status'=>$e->getMessage()]);}
   $lines=DB::table('journal_lines')->where('tenant_id',$tenant)
    ->where('journal_entry_id',$entry)->get();
   try{\App\Domain\Accounting\JournalValidator::validate(
    $lines->map(fn($l)=>['debit_halalas'=>(int)$l->debit_halalas,
      'credit_halalas'=>(int)$l->credit_halalas])->all()
   );}catch(\DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
   $accountIds=$lines->pluck('ledger_account_id')->unique()->all();
   $activeCount=DB::table('ledger_accounts')->where('tenant_id',$tenant)
    ->where('active',true)->whereIn('id',$accountIds)->count();
   if($activeCount!==count($accountIds))
    throw ValidationException::withMessages(['lines'=>'Inactive or invalid ledger account']);
   DB::table('journal_entries')->where('tenant_id',$tenant)->where('id',$entry)
    ->update(['status'=>'posted','posted_by'=>$request->user()->id,
      'posted_at'=>now(),'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'journal.posted','resource_type'=>'journal_entry','resource_id'=>(string)$entry,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$entry,'status'=>'posted']);
  });
 }

}
