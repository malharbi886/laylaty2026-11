<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;

final class MyTenantsController extends Controller {
    public function index(Request $request) {
        $user = $request->user();
        if (!$user) abort(401);
        $rows = DB::table('tenant_memberships as m')
            ->join('tenants as t', 't.id', '=', 'm.tenant_id')
            ->where('m.user_id', $user->id)
            ->whereIn('m.role', ['owner','manager','accountant','cashier','staff','viewer'])
            ->select('t.public_id', 't.name', 't.type', 'm.role')
            ->orderBy('t.name')->get();
        return response()->json(['tenants' => $rows]);
    }
}
