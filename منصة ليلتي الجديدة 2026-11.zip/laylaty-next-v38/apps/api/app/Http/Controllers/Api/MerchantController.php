<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Audit\AuditRecorder;
use App\Domain\Merchants\MerchantPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
final class MerchantController extends Controller {
 private function access(Request $request,int $tenant,bool $write=false):void {
  $type=DB::table('tenants')->where('id',$tenant)->value('type');
  if(!$type)abort(404);
  try{MerchantPolicy::requireStore($type);}catch(DomainException $e){abort(403);}
  $role=$request->attributes->get('laylaty_role');
  if(!in_array($role,$write?['owner','manager']:['owner','manager','accountant','viewer'],true))abort(403);
 }
 public function items(Request $request,int $tenant){
  $this->access($request,$tenant);
  return DB::table('catalog_items')->where('tenant_id',$tenant)->paginate(30);
 }
 public function addItem(Request $request,int $tenant){
  $this->access($request,$tenant,true);
  $d=$request->validate(['sku'=>'required|string|max:100','name'=>'required|string|max:255',
   'kind'=>'required|in:product,service,rental','price_halalas'=>'required|integer|min:0|max:100000000000']);
  $id=DB::transaction(function() use ($request,$tenant,$d) {
   $id=DB::table('catalog_items')->insertGetId([...$d,'tenant_id'=>$tenant,'active'=>true,
    'created_at'=>now(),'updated_at'=>now()]);
   AuditRecorder::record($request,$tenant,'catalog_item.created','catalog_item',(string)$id);
   return $id;
  });
  return response()->json(['id'=>$id],201);
 }
 public function orders(Request $request,int $tenant){
  $this->access($request,$tenant);
  return DB::table('merchant_orders')->where('tenant_id',$tenant)->orderByDesc('id')->paginate(30);
 }
 public function createOrder(Request $request,int $tenant){
  $this->access($request,$tenant,true);
  $d=$request->validate(['branch_id'=>'required|integer','delivery_at'=>'nullable|date',
   'lines'=>'required|array|min:1|max:100','lines.*.item_id'=>'required|integer',
   'lines.*.quantity'=>'required|integer|min:1|max:100000']);
  return DB::transaction(function()use($request,$tenant,$d){
   if(!DB::table('branches')->where('tenant_id',$tenant)->where('id',$d['branch_id'])->exists())abort(404);
   $ids=array_unique(array_column($d['lines'],'item_id'));
   $items=DB::table('catalog_items')->where('tenant_id',$tenant)->where('active',true)
    ->whereIn('id',$ids)->get()->keyBy('id');
   if($items->count()!==count($ids))throw ValidationException::withMessages(['lines'=>'Invalid item']);
   $lines=[];
   foreach($d['lines'] as $line){
    $item=$items->get($line['item_id']);
    $lines[]=['catalog_item_id'=>$item->id,'name_snapshot'=>$item->name,
     'quantity'=>(int)$line['quantity'],'unit_price_halalas'=>(int)$item->price_halalas];
   }
   try{$total=MerchantPolicy::orderTotal($lines);}
   catch(DomainException $e){throw ValidationException::withMessages(['lines'=>$e->getMessage()]);}
   $id=DB::table('merchant_orders')->insertGetId(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'reference'=>'LY-O-'.Str::upper((string)Str::ulid()),'status'=>'new',
    'total_halalas'=>$total,'delivery_at'=>$d['delivery_at']??null,
    'created_at'=>now(),'updated_at'=>now()]);
   foreach($lines as $line)DB::table('merchant_order_lines')->insert([
    ...$line,'tenant_id'=>$tenant,'merchant_order_id'=>$id,
    'line_total_halalas'=>$line['quantity']*$line['unit_price_halalas'],
    'created_at'=>now(),'updated_at'=>now()]);
   AuditRecorder::record($request,$tenant,'merchant_order.created','merchant_order',(string)$id);
   return response()->json(['id'=>$id,'total_halalas'=>$total,'status'=>'new'],201);
  });
 }
}
