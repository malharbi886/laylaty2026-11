<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use App\Domain\Bookings\BookingStateMachine;
final class BookingController extends Controller {
 private function check(Request $request,string $permission):void {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),$permission)) abort(403);
 }
 public function index(Request $request, int $tenant) {
  $this->check($request,'bookings.read');
  return DB::table('bookings')->where('tenant_id',$tenant)
   ->orderBy('starts_at')->paginate(25);
 }
 public function show(Request $request,int $tenant,int $booking) {
  $this->check($request,'bookings.read');
  $row=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)->first();
  if(!$row) abort(404);
  return response()->json($row);
 }
 public function store(Request $request,int $tenant) {
  $this->check($request,'bookings.write');
  $data=$request->validate([
   'branch_id'=>'required|integer','hall_id'=>'required|integer','starts_at'=>'required|date',
   'ends_at'=>'required|date|after:starts_at','total_halalas'=>'required|integer|min:0',
  ]);
  $id=DB::transaction(function() use ($tenant,$data,$request) {
   $branch=DB::table('branches')->where('tenant_id',$tenant)
    ->where('id',$data['branch_id'])->lockForUpdate()->first();
   if(!$branch) abort(404);
   $hall=DB::table('halls')->where('tenant_id',$tenant)
    ->where('branch_id',$data['branch_id'])->where('id',$data['hall_id'])
    ->where('is_active',true)->lockForUpdate()->first();
   if(!$hall) abort(404);
   $overlap=DB::table('bookings')->where('tenant_id',$tenant)
    ->where('hall_id',$data['hall_id'])
    ->whereIn('status',['pending','confirmed'])
    ->where('starts_at','<',$data['ends_at'])
    ->where('ends_at','>',$data['starts_at'])->exists();
   if($overlap) throw ValidationException::withMessages(['starts_at'=>'Booking slot unavailable']);
   $id=DB::table('bookings')->insertGetId([
    ...$data,'tenant_id'=>$tenant,'reference'=>'LY-H-'.Str::upper((string)Str::ulid()),
    'status'=>'pending','created_at'=>now(),'updated_at'=>now()
   ]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'booking.created','resource_type'=>'booking','resource_id'=>(string)$id,'created_at'=>now(),'updated_at'=>now()]);
   return $id;
  });
  return response()->json(['id'=>$id],201);
 }
 public function confirm(Request $request,int $tenant,int $booking) {
  $this->check($request,'bookings.confirm');
  return DB::transaction(function()use($request,$tenant,$booking){
   $initial=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)->first();
   if(!$initial) abort(404);
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$initial->branch_id)->lockForUpdate()->first();
   if(!$branch)abort(404);
   if(!$initial->hall_id) abort(422,'Hall must be assigned before confirmation');
   $hall=DB::table('halls')->where('tenant_id',$tenant)->where('branch_id',$initial->branch_id)
    ->where('id',$initial->hall_id)->lockForUpdate()->first();
   if(!$hall)abort(404);
   $row=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)->lockForUpdate()->first();
   if(!$row) abort(404);
   BookingStateMachine::transition($row->status,'confirmed');
   $conflict=DB::table('bookings')->where('tenant_id',$tenant)
    ->where('hall_id',$row->hall_id)->where('id','!=',$booking)
    ->where('status','confirmed')->where('starts_at','<',$row->ends_at)
    ->where('ends_at','>',$row->starts_at)->exists();
   if($conflict) throw ValidationException::withMessages(['booking'=>'Booking slot unavailable']);
   DB::table('bookings')->where('id',$booking)->where('tenant_id',$tenant)
    ->update(['status'=>'confirmed','updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'booking.confirmed','resource_type'=>'booking','resource_id'=>(string)$booking,'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$booking,'status'=>'confirmed']);
  });
 }
}
