<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Inventory\StockMovement;
use App\Domain\Inventory\TransferPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class StockTransferController extends Controller {
 public function store(Request $request,int $tenant){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($request->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
  $d=$request->validate(['reference'=>'required|string|max:80','source_branch_id'=>'required|integer|min:1',
   'destination_branch_id'=>'required|integer|min:1','item_id'=>'required|integer|min:1',
   'quantity'=>'required|integer|between:1,1000000']);
  try{TransferPolicy::validate((int)$d['source_branch_id'],(int)$d['destination_branch_id'],(int)$d['quantity']);}
  catch(DomainException $e){throw ValidationException::withMessages(['quantity'=>$e->getMessage()]);}
  return DB::transaction(function()use($request,$tenant,$d){
   // Lock branches in stable order: serializes new balances and avoids reverse-transfer deadlocks.
   $ids=[$d['source_branch_id'],$d['destination_branch_id']];sort($ids,SORT_NUMERIC);
   $branches=DB::table('branches')->where('tenant_id',$tenant)->whereIn('id',$ids)
    ->orderBy('id')->lockForUpdate()->get();
   if($branches->count()!==2)abort(404);
   $prior=DB::table('store_stock_transfers')->where('tenant_id',$tenant)->where('reference',$d['reference'])->first();
   if($prior){
    foreach(['source_branch_id','destination_branch_id','item_id','quantity'] as $key)
     if((int)$prior->$key!==(int)$d[$key])throw ValidationException::withMessages(['reference'=>'Reference conflict']);
    return response()->json(['id'=>$prior->id,'replayed'=>true]);
   }
   $item=DB::table('catalog_items')->where('tenant_id',$tenant)->where('id',$d['item_id'])->first();
   if(!$item||$item->kind!=='product')throw ValidationException::withMessages(['item_id'=>'Stocked product required']);
   $balances=[];
   foreach($ids as $branch){
    $balances[$branch]=DB::table('inventory_balances')->where('tenant_id',$tenant)
     ->where('branch_id',$branch)->where('item_id',$d['item_id'])->lockForUpdate()->first();
   }
   $src=$d['source_branch_id'];$dst=$d['destination_branch_id'];
   $beforeSrc=$balances[$src]?(int)$balances[$src]->quantity:0;
   $beforeDst=$balances[$dst]?(int)$balances[$dst]->quantity:0;
   try{[$afterSrc,$afterDst]=TransferPolicy::move($beforeSrc,$beforeDst,(int)$d['quantity']);}
   catch(DomainException $e){throw ValidationException::withMessages(['quantity'=>$e->getMessage()]);}
   foreach([[$src,$afterSrc],[$dst,$afterDst]] as [$branch,$after]){
    if($balances[$branch])DB::table('inventory_balances')->where('id',$balances[$branch]->id)->where('tenant_id',$tenant)
     ->update(['quantity'=>$after,'updated_at'=>now()]);
    else DB::table('inventory_balances')->insert(['tenant_id'=>$tenant,'branch_id'=>$branch,
     'item_id'=>$d['item_id'],'quantity'=>$after,'created_at'=>now(),'updated_at'=>now()]);
   }
   $id=DB::table('store_stock_transfers')->insertGetId([...$d,'tenant_id'=>$tenant,
    'created_by'=>$request->user()->id,'created_at'=>now(),'updated_at'=>now()]);
   foreach([['branch'=>$src,'delta'=>-$d['quantity'],'before'=>$beforeSrc,'after'=>$afterSrc,'suffix'=>'OUT'],
    ['branch'=>$dst,'delta'=>$d['quantity'],'before'=>$beforeDst,'after'=>$afterDst,'suffix'=>'IN']] as $m){
    DB::table('inventory_movements')->insert(['tenant_id'=>$tenant,'branch_id'=>$m['branch'],
     'item_id'=>$d['item_id'],'reference'=>'T'.$id.'-'.$m['suffix'],'kind'=>'transfer',
     'delta'=>$m['delta'],'quantity_before'=>$m['before'],'quantity_after'=>$m['after'],
     'actor_id'=>$request->user()->id,'reason'=>'Stock transfer '.$d['reference'],
     'created_at'=>now(),'updated_at'=>now()]);
   }
   return response()->json(['id'=>$id,'replayed'=>false],201);
  },3);
 }
}
