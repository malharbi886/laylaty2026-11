<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Inventory\StockMovement;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class InventoryController extends Controller {
 private function check(Request $request,int $tenant,bool $write):void {
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  $roles=$write?['owner','manager']:['owner','manager','accountant','viewer'];
  if(!in_array($request->attributes->get('laylaty_role'),$roles,true))abort(403);
 }
 public function balances(Request $request,int $tenant){
  $this->check($request,$tenant,false);
  $data=$request->validate(['branch_id'=>'required|integer|min:1']);
  if(!DB::table('branches')->where('tenant_id',$tenant)->where('id',$data['branch_id'])->exists())abort(404);
  return DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$data['branch_id'])->orderBy('item_id')->paginate(50);
 }
 public function movements(Request $request,int $tenant){
  $this->check($request,$tenant,false);
  $data=$request->validate(['branch_id'=>'required|integer|min:1']);
  if(!DB::table('branches')->where('tenant_id',$tenant)->where('id',$data['branch_id'])->exists())abort(404);
  return DB::table('inventory_movements')->where('tenant_id',$tenant)->where('branch_id',$data['branch_id'])->orderByDesc('id')->paginate(50);
 }
 public function adjust(Request $request,int $tenant){
  $this->check($request,$tenant,true);
  $d=$request->validate(['branch_id'=>'required|integer|min:1','item_id'=>'required|integer|min:1',
   'reference'=>'required|string|max:100','delta'=>'required|integer|between:-1000000,1000000|not_in:0',
   'reason'=>'required|string|min:5|max:500']);
  return DB::transaction(function()use($request,$tenant,$d){
   // The branch lock serializes first-time balance creation and prevents duplicate concurrent inserts.
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$d['branch_id'])->lockForUpdate()->first();
   if(!$branch)abort(404);
   $prior=DB::table('inventory_movements')->where('tenant_id',$tenant)->where('reference',$d['reference'])->first();
   if($prior){
    if((int)$prior->branch_id!==(int)$d['branch_id']||(int)$prior->item_id!==(int)$d['item_id']||
      (int)$prior->delta!==(int)$d['delta']||$prior->reason!==$d['reason'])
      throw ValidationException::withMessages(['reference'=>'Reference already used with different values']);
    return response()->json(['id'=>$prior->id,'quantity_after'=>$prior->quantity_after,'replayed'=>true]);
   }
   $item=DB::table('catalog_items')->where('tenant_id',$tenant)->where('id',$d['item_id'])->first();
   if(!$item||$item->kind!=='product')throw ValidationException::withMessages(['item_id'=>'Only store products have stock balances']);
   $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$d['branch_id'])
    ->where('item_id',$d['item_id'])->lockForUpdate()->first();
   $before=$balance?(int)$balance->quantity:0;
   try{$after=StockMovement::next($before,(int)$d['delta']);}
   catch(DomainException $e){throw ValidationException::withMessages(['delta'=>$e->getMessage()]);}
   if($balance){DB::table('inventory_balances')->where('id',$balance->id)->where('tenant_id',$tenant)
    ->update(['quantity'=>$after,'updated_at'=>now()]);}
   else {DB::table('inventory_balances')->insert(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'item_id'=>$d['item_id'],'quantity'=>$after,'created_at'=>now(),'updated_at'=>now()]);}
   $id=DB::table('inventory_movements')->insertGetId(['tenant_id'=>$tenant,'branch_id'=>$d['branch_id'],
    'item_id'=>$d['item_id'],'reference'=>$d['reference'],'kind'=>StockMovement::type((int)$d['delta']),
    'delta'=>$d['delta'],'quantity_before'=>$before,'quantity_after'=>$after,'actor_id'=>$request->user()->id,
    'reason'=>$d['reason'],'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'quantity_after'=>$after,'replayed'=>false],201);
  },3);
 }
}
