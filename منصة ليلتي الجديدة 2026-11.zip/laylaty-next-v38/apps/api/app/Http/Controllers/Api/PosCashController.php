<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\POS\CashSalePolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PosCashController extends Controller {
 private function access(Request $r,int $tenant):void {
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
 }
 public function complete(Request $r,int $tenant,int $shift,int $sale){
  $this->access($r,$tenant);
  return DB::transaction(function()use($r,$tenant,$shift,$sale){
   $s=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('id',$shift)->lockForUpdate()->first();
   if(!$s)abort(404);
   $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('shift_id',$shift)->where('id',$sale)->lockForUpdate()->first();
   if(!$row)abort(404);
   $prior=DB::table('pos_cash_receipts')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
   if($prior&&$row->status==='completed')return response()->json(['sale_id'=>$sale,'status'=>'completed','replayed'=>true]);
   try{CashSalePolicy::complete($row->status,$s->status);}catch(DomainException $e){throw ValidationException::withMessages(['sale'=>$e->getMessage()]);}
   // Lock branch before stock balances, serializing balance initialization.
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$s->branch_id)->lockForUpdate()->first();
   if(!$branch)abort(404);
   $lines=DB::table('pos_sale_lines as l')->join('catalog_items as i',function($j){
    $j->on('i.id','=','l.item_id')->on('i.tenant_id','=','l.tenant_id');
   })->where('l.tenant_id',$tenant)->where('l.sale_id',$sale)
    ->select('l.item_id','l.quantity','l.line_total_halalas','i.kind')->get();
   if($lines->isEmpty())throw ValidationException::withMessages(['sale'=>'Sale has no lines']);
   $sum=0;$quantities=[];
   foreach($lines as $line){
    $amount=(int)$line->line_total_halalas;
    if($amount<0||$amount>PHP_INT_MAX-$sum)throw ValidationException::withMessages(['sale'=>'Invalid total']);
    $sum+=$amount;
    if($line->kind==='product')$quantities[$line->item_id]=($quantities[$line->item_id]??0)+(int)$line->quantity;
   }
   if($sum!==(int)$row->total_halalas)throw ValidationException::withMessages(['sale'=>'Total mismatch']);
   ksort($quantities,SORT_NUMERIC);
   foreach($quantities as $itemId=>$qty){
    $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$s->branch_id)->where('item_id',$itemId)->lockForUpdate()->first();
    if(!$balance||(int)$balance->quantity<$qty)throw ValidationException::withMessages(['inventory'=>'Insufficient stock']);
    $before=(int)$balance->quantity;$after=$before-$qty;
    DB::table('inventory_balances')->where('tenant_id',$tenant)->where('id',$balance->id)->update(['quantity'=>$after,'updated_at'=>now()]);
    DB::table('inventory_movements')->insert(['tenant_id'=>$tenant,'branch_id'=>$s->branch_id,'item_id'=>$itemId,
     'reference'=>'POS-'.$sale.'-'.$itemId,'kind'=>'pos_sale','delta'=>-$qty,'quantity_before'=>$before,
     'quantity_after'=>$after,'actor_id'=>$r->user()->id,'reason'=>'Cash POS sale '.$sale,
     'created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('pos_cash_receipts')->insert(['tenant_id'=>$tenant,'sale_id'=>$sale,'amount_halalas'=>$sum,
    'collected_by'=>$r->user()->id,'created_at'=>now(),'updated_at'=>now()]);
   DB::table('pos_sales')->where('tenant_id',$tenant)->where('id',$sale)->update(['status'=>'completed','updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'pos_sale.cash_completed','resource_type'=>'pos_sale','resource_id'=>(string)$sale,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['sale_id'=>$sale,'status'=>'completed','amount_halalas'=>$sum,'replayed'=>false]);
  },3);
 }
}
