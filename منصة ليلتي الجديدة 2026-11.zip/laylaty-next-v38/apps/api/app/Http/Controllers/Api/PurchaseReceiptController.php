<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Merchants\ReceiptPolicy;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PurchaseReceiptController extends Controller {
 public function receive(Request $r,int $tenant,int $purchase){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','manager'],true))abort(403);
  return DB::transaction(function()use($r,$tenant,$purchase){
   $po=DB::table('store_purchase_orders')->where('tenant_id',$tenant)->where('id',$purchase)->lockForUpdate()->first();
   if(!$po)abort(404);
   if($po->status==='received')return response()->json(['id'=>$purchase,'status'=>'received','replayed'=>true]);
   try{ReceiptPolicy::receive($po->status);}catch(DomainException $e){throw ValidationException::withMessages(['purchase'=>$e->getMessage()]);}
   // Serialize inventory updates per branch, including first balance creation.
   $branch=DB::table('branches')->where('tenant_id',$tenant)->where('id',$po->branch_id)->lockForUpdate()->first();
   if(!$branch)abort(404);
   $lines=DB::table('store_purchase_lines')->where('tenant_id',$tenant)->where('purchase_id',$purchase)->orderBy('item_id')->get();
   if($lines->isEmpty())throw ValidationException::withMessages(['purchase'=>'Empty purchase']);
   // Consolidate duplicate product lines before adjusting stock.
   $quantities=[];
   foreach($lines as $line){
    $key=(int)$line->item_id;
    $quantities[$key]=($quantities[$key]??0)+(int)$line->quantity;
   }
   ksort($quantities,SORT_NUMERIC);
   foreach($quantities as $itemId=>$quantity){
    $item=DB::table('catalog_items')->where('tenant_id',$tenant)->where('id',$itemId)->where('kind','product')->first();
    if(!$item)throw ValidationException::withMessages(['purchase'=>'Invalid product']);
    $balance=DB::table('inventory_balances')->where('tenant_id',$tenant)->where('branch_id',$po->branch_id)->where('item_id',$itemId)->lockForUpdate()->first();
    $before=$balance?(int)$balance->quantity:0;
    try{$after=ReceiptPolicy::nextQuantity($before,$quantity);}catch(DomainException $e){throw ValidationException::withMessages(['purchase'=>$e->getMessage()]);}
    if($balance)DB::table('inventory_balances')->where('id',$balance->id)->where('tenant_id',$tenant)->update(['quantity'=>$after,'updated_at'=>now()]);
    else DB::table('inventory_balances')->insert(['tenant_id'=>$tenant,'branch_id'=>$po->branch_id,'item_id'=>$itemId,'quantity'=>$after,'created_at'=>now(),'updated_at'=>now()]);
    DB::table('inventory_movements')->insert(['tenant_id'=>$tenant,'branch_id'=>$po->branch_id,'item_id'=>$itemId,
     'reference'=>'PO-'.$purchase.'-ITEM-'.$itemId,'kind'=>'purchase_receipt','delta'=>$quantity,
     'quantity_before'=>$before,'quantity_after'=>$after,'actor_id'=>$r->user()->id,
     'reason'=>'Purchase order '.$purchase.' received','created_at'=>now(),'updated_at'=>now()]);
   }
   DB::table('store_purchase_orders')->where('id',$purchase)->where('tenant_id',$tenant)->update(['status'=>'received','updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,'event'=>'purchase.received',
    'resource_type'=>'purchase','resource_id'=>(string)$purchase,'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$purchase,'status'=>'received','replayed'=>false]);
  },3);
 }
}
