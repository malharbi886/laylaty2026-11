<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use App\Domain\Payments\PaymentSubmissionPolicy;
use DomainException;
final class PaymentController extends Controller {
 public function store(Request $request,int $tenant,int $booking) {
  if(!\App\Domain\Tenancy\RolePermissions::allows((string)$request->attributes->get('laylaty_role'),'payments.record')) abort(403);
  $data=$request->validate([
   'amount_halalas'=>'required|integer|min:1',
   'method'=>'required|in:bank_transfer,cash,card',
   'external_reference'=>'required|string|min:8|max:120'
  ]);
  return DB::transaction(function()use($request,$tenant,$booking,$data){
   $row=DB::table('bookings')->where('tenant_id',$tenant)->where('id',$booking)->lockForUpdate()->first();
   if(!$row) abort(404);
   // Unique tenant/reference constraint in the database is the final idempotency guard.
   $existing=DB::table('booking_payments')->where('tenant_id',$tenant)
    ->where('external_reference',$data['external_reference'])->first();
   if($existing){
    if((int)$existing->booking_id!==$booking || (int)$existing->amount_halalas!==$data['amount_halalas'] || $existing->method!==$data['method'])
     throw ValidationException::withMessages(['external_reference'=>'Reference already used with different payment details']);
    return response()->json(['id'=>$existing->id,'status'=>$existing->status,'replayed'=>true],200);
   }
   $payments=DB::table('booking_payments')->where('tenant_id',$tenant)->where('booking_id',$booking)
    ->whereIn('status',['pending','approved'])->get(['amount_halalas','status'])
    ->map(fn($p)=>['amount_halalas'=>(int)$p->amount_halalas,'status'=>$p->status])->all();
   try {PaymentSubmissionPolicy::assertCanSubmit((int)$row->total_halalas,$payments,(int)$data['amount_halalas']);}
   catch(DomainException $e){throw ValidationException::withMessages(['amount_halalas'=>$e->getMessage()]);}
   $id=DB::table('booking_payments')->insertGetId([
    ...$data,'tenant_id'=>$tenant,'booking_id'=>$booking,'status'=>'pending',
    'created_at'=>now(),'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$request->user()->id,
    'event'=>'payment.submitted','resource_type'=>'booking_payment','resource_id'=>(string)$id,'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['id'=>$id,'status'=>'pending'],201);
  });
 }
}
