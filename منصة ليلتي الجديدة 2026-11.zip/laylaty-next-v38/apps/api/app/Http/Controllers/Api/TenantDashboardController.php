<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
final class TenantDashboardController extends Controller {
 public function summary(Request $request,int $tenant){
  $context=$request->attributes->get('laylaty_context');
  if (!$context instanceof \App\Domain\Tenancy\TenantContext) abort(403);
  try {$context->requireTenant($tenant);} catch (\DomainException $e) {abort(404);}
  $role=$context->role;
  if(!in_array($role,['owner','manager','accountant','viewer'],true))abort(403);
  $kind=DB::table('tenants')->where('id',$tenant)->value('type');
  if(!$kind)abort(404);
  $data=['tenant_id'=>$tenant,'tenant_type'=>$kind,
   'branches'=>DB::table('branches')->where('tenant_id',$tenant)->count(),
   'bookings'=>DB::table('bookings')->where('tenant_id',$tenant)->count(),
   'pending_payments'=>DB::table('booking_payments')->where('tenant_id',$tenant)->where('status','pending')->count()];
  if($kind==='store'){
   $data['catalog_items']=DB::table('catalog_items')->where('tenant_id',$tenant)->count();
   $data['orders']=DB::table('merchant_orders')->where('tenant_id',$tenant)->count();
   $data['open_shifts']=DB::table('pos_shifts')->where('tenant_id',$tenant)->where('status','open')->count();
  }
  return response()->json($data);
 }
}
