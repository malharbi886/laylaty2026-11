<?php
declare(strict_types=1);
namespace App\Http\Controllers\Api;
use App\Domain\Accounting\PosJournalDraft;
use DomainException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
final class PosAccountingController extends Controller {
 public function createDraft(Request $r,int $tenant,int $sale){
  if(DB::table('tenants')->where('id',$tenant)->value('type')!=='store')abort(403);
  if(!in_array($r->attributes->get('laylaty_role'),['owner','accountant'],true))abort(403);
  $data=$r->validate(['kind'=>'required|in:sale,refund',
   'cash_account_id'=>'required|integer|min:1','sales_account_id'=>'required|integer|min:1']);
  return DB::transaction(function()use($r,$tenant,$sale,$data){
   $row=DB::table('pos_sales')->where('tenant_id',$tenant)->where('id',$sale)->lockForUpdate()->first();
   if(!$row)abort(404);
   $kind=$data['kind'];
   $existing=DB::table('pos_accounting_links')->where('tenant_id',$tenant)->where('sale_id',$sale)->where('kind',$kind)->first();
   if($existing)return response()->json(['journal_entry_id'=>$existing->journal_entry_id,'replayed'=>true]);
   $receipt=DB::table('pos_cash_receipts')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
   $refund=DB::table('pos_cash_refunds')->where('tenant_id',$tenant)->where('sale_id',$sale)->first();
   if(!$receipt||($kind==='sale'&&!in_array($row->status,['completed','refunded'],true))||($kind==='refund'&&(!$refund||$row->status!=='refunded')))
    throw ValidationException::withMessages(['sale'=>'POS cash event not eligible']);
   $amount=(int)($kind==='sale'?$receipt->amount_halalas:$refund->amount_halalas);
   $accountIds=[(int)$data['cash_account_id'],(int)$data['sales_account_id']];
   if(DB::table('ledger_accounts')->where('tenant_id',$tenant)->where('active',true)->whereIn('id',$accountIds)->count()!==2)
    throw ValidationException::withMessages(['accounts'=>'Accounts must be active in this tenant']);
   try{$lines=PosJournalDraft::lines($kind,$amount,$accountIds[0],$accountIds[1]);}
   catch(DomainException $e){throw ValidationException::withMessages(['journal'=>$e->getMessage()]);}
   $id=DB::table('journal_entries')->insertGetId(['tenant_id'=>$tenant,
    'reference'=>'POS-'.$kind.'-'.$sale,'status'=>'draft','entry_date'=>now()->toDateString(),
    'description'=>'POS '.$kind.' #'.$sale.' — review taxes and revenue recognition before posting',
    'created_by'=>$r->user()->id,'created_at'=>now(),'updated_at'=>now()]);
   foreach($lines as $line)DB::table('journal_lines')->insert(['tenant_id'=>$tenant,'journal_entry_id'=>$id,
    'ledger_account_id'=>$line['account_id'],'debit_halalas'=>$line['debit_halalas'],
    'credit_halalas'=>$line['credit_halalas'],'created_at'=>now(),'updated_at'=>now()]);
   DB::table('pos_accounting_links')->insert(['tenant_id'=>$tenant,'sale_id'=>$sale,
    'journal_entry_id'=>$id,'kind'=>$kind,'created_at'=>now(),'updated_at'=>now()]);
   DB::table('audit_events')->insert(['tenant_id'=>$tenant,'actor_id'=>$r->user()->id,
    'event'=>'pos_accounting.draft_created','resource_type'=>'journal_entry','resource_id'=>(string)$id,
    'created_at'=>now(),'updated_at'=>now()]);
   return response()->json(['journal_entry_id'=>$id,'status'=>'draft','replayed'=>false],201);
  },3);
 }
}
