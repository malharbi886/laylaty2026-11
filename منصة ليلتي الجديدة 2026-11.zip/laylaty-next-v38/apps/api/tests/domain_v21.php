<?php
require __DIR__.'/../app/Domain/POS/CashSalePolicy.php';
use App\Domain\POS\CashSalePolicy;
assert(CashSalePolicy::complete('draft','open')==='completed');
assert(CashSalePolicy::expectedCash(500,[150,200])===850);
foreach([fn()=>CashSalePolicy::complete('cancelled','open'),fn()=>CashSalePolicy::complete('draft','closed'),fn()=>CashSalePolicy::expectedCash(10,[-1])] as $fn){
 try{$fn();throw new RuntimeException('Should reject');}catch(DomainException $e){}
}
echo "V21 cash sale checks passed\n";
