<?php
require __DIR__.'/../app/Domain/Tenancy/RolePermissions.php';
use App\Domain\Tenancy\RolePermissions;
assert(RolePermissions::allows('owner','bookings.write'));
assert(RolePermissions::allows('booking_manager','bookings.confirm'));
assert(RolePermissions::allows('accountant','payments.record'));
assert(!RolePermissions::allows('viewer','bookings.write'));
assert(!RolePermissions::allows('accountant','bookings.confirm'));
assert(!RolePermissions::allows('unknown','bookings.read'));
assert(!RolePermissions::allows('manager','journals.write'));
echo "V10 role permission checks passed\n";
