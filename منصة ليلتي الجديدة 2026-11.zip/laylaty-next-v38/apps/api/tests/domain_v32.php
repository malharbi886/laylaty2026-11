<?php
declare(strict_types=1);
require __DIR__.'/../app/Domain/Tenancy/AccessPolicy.php';
require __DIR__.'/../app/Domain/Tenancy/TenantContext.php';
use App\Domain\Tenancy\TenantContext;
function denies(callable $fn):void {try{$fn();}catch(DomainException $e){return;}throw new RuntimeException('Expected denial');}
$c=new TenantContext(10,21,'manager','store');
$c->requireTenant(10);$c->requireRole(['owner','manager']);$c->requireType('store');
denies(fn()=>$c->requireTenant(11));
denies(fn()=>$c->requireRole(['owner']));
denies(fn()=>$c->requireType('hall'));
denies(fn()=>new TenantContext(0,21,'owner','store'));
denies(fn()=>new TenantContext(10,0,'owner','store'));
denies(fn()=>new TenantContext(10,21,'superadmin','store'));
denies(fn()=>new TenantContext(10,21,'owner','unexpected'));
foreach(['0','-1','1e2','01','2.0','9999999999999999999999999999',null,1.0] as $bad){denies(fn()=>TenantContext::positiveId($bad));}
assert(TenantContext::positiveId('123')===123);
assert(TenantContext::positiveId(123)===123);
echo "V32 tenant context checks passed\n";
