<?php
declare(strict_types=1);
require __DIR__.'/../app/Domain/Payments/PaymentSubmissionPolicy.php';
require __DIR__.'/../app/Domain/Tenancy/RolePermissions.php';
use App\Domain\Payments\PaymentSubmissionPolicy as P;
use App\Domain\Tenancy\RolePermissions as R;
assert(P::available(10000,[['status'=>'pending','amount_halalas'=>2000],['status'=>'approved','amount_halalas'=>3000],['status'=>'rejected','amount_halalas'=>9000]])===5000);
P::assertCanSubmit(10000,[['status'=>'pending','amount_halalas'=>2000]],8000);
try{P::assertCanSubmit(10000,[['status'=>'pending','amount_halalas'=>2000]],8001);throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
assert(R::allows('owner','invoices.read'));
assert(!R::allows('viewer','payments.record'));
assert(!R::allows('unknown','bookings.read'));
echo "V11 payment safety checks passed\n";
