<?php
require __DIR__.'/../app/Domain/POS/SaleDraftPolicy.php';
use App\Domain\POS\SaleDraftPolicy;
assert(SaleDraftPolicy::cancel('draft')==='cancelled');
assert(SaleDraftPolicy::canCloseShift([]));
assert(SaleDraftPolicy::canCloseShift(['cancelled','cancelled']));
assert(!SaleDraftPolicy::canCloseShift(['cancelled','draft']));
assert(!SaleDraftPolicy::canCloseShift(['completed']));
foreach(['cancelled','completed','paid'] as $status){
 try{SaleDraftPolicy::cancel($status);throw new RuntimeException('Expected exception');}
 catch(DomainException $e){}
}
echo "V20 POS draft safety checks passed\n";
