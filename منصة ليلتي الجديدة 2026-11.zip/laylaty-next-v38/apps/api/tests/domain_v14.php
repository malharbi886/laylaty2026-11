<?php
require __DIR__.'/../app/Domain/Inventory/StockMovement.php';
use App\Domain\Inventory\StockMovement;
assert(StockMovement::next(10,5)===15);
assert(StockMovement::next(10,-4)===6);
assert(StockMovement::type(2)==='receipt');
foreach([[0,-1],[2,-3],[5,0],[2147483647,1]] as [$a,$b]){
 try{StockMovement::next($a,$b);throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V14 stock movement tests passed\n";
