<?php
require __DIR__.'/../app/Domain/POS/PartialRefundPolicy.php';
use App\Domain\POS\PartialRefundPolicy;
$sold=[['line_id'=>7,'quantity'=>3,'line_total_halalas'=>100]];
$a=PartialRefundPolicy::calculate($sold,[],[7=>1]);
$b=PartialRefundPolicy::calculate($sold,[7=>1],[7=>1]);
$c=PartialRefundPolicy::calculate($sold,[7=>2],[7=>1]);
assert($a['total_halalas']+$b['total_halalas']+$c['total_halalas']===100);
assert($a['total_halalas']===33 && $b['total_halalas']===34 && $c['total_halalas']===33);
foreach([fn()=>PartialRefundPolicy::calculate($sold,[7=>2],[7=>2]),fn()=>PartialRefundPolicy::calculate($sold,[],[8=>1]),fn()=>PartialRefundPolicy::calculate($sold,[],[])] as $fn){
 try{$fn();throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
}
echo "V26 partial refund policy checks passed\n";
