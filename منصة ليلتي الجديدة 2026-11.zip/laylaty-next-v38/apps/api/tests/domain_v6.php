<?php
require __DIR__.'/../app/Domain/Bookings/SlotPolicy.php';
require __DIR__.'/../app/Domain/Contracts/ContractMath.php';
use App\Domain\Bookings\SlotPolicy;
use App\Domain\Contracts\ContractMath;
assert(SlotPolicy::overlaps('2026-11-20 18:00:00','2026-11-21 01:00:00','2026-11-20 20:00:00','2026-11-20 22:00:00'));
assert(!SlotPolicy::overlaps('2026-11-20 18:00:00','2026-11-20 20:00:00','2026-11-20 20:00:00','2026-11-20 22:00:00'));
assert(ContractMath::servicesTotal([['quantity'=>2,'unit_price_halalas'=>15000]])===30000);
try{ContractMath::servicesTotal([['quantity'=>0,'unit_price_halalas'=>15000]]);throw new Exception('Expected failure');}catch(InvalidArgumentException $e){}
echo "V6 domain checks passed\n";
