<?php
require __DIR__.'/../app/Domain/Contracts/ContractStatus.php';
require __DIR__.'/../app/Domain/Accounting/JournalStatus.php';
use App\Domain\Contracts\ContractStatus;
use App\Domain\Accounting\JournalStatus;
assert(ContractStatus::approve('draft')==='approved');
assert(JournalStatus::post('draft')==='posted');
foreach([fn()=>ContractStatus::approve('approved'),fn()=>JournalStatus::post('posted')] as $fn) {
 try{$fn();throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V8 status checks passed\n";
