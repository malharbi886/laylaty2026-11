<?php
declare(strict_types=1);
require __DIR__.'/../app/Domain/Tenancy/AccessPolicy.php';
require __DIR__.'/../app/Domain/Tenancy/TenantContext.php';
require __DIR__.'/../app/Domain/Tenancy/TenantScope.php';
use App\Domain\Tenancy\TenantContext;
use App\Domain\Tenancy\TenantScope;
$c=new TenantContext(101,55,'manager','store');
assert(TenantScope::requireResourceTenant($c,101)===101);
TenantScope::requireBranchInTenant($c,'101');
assert(TenantScope::requireCustomerOwner(55,55)===55);
$denied=0;
foreach([fn()=>TenantScope::requireResourceTenant($c,102),fn()=>TenantScope::requireResourceTenant($c,'00101'),fn()=>TenantScope::requireResourceTenant($c,0),fn()=>TenantScope::requireBranchInTenant($c,999),fn()=>TenantScope::requireCustomerOwner(55,56),fn()=>TenantScope::requireCustomerOwner(55,'55.0')] as $call){try{$call();}catch(DomainException $e){$denied++;}}
assert($denied===6);
$controllers=__DIR__.'/../app/Http/Controllers/Api/';
$customer=file_get_contents($controllers.'CustomerEventController.php');
$booking=file_get_contents($controllers.'BookingController.php');
assert(str_contains($customer,"->where('customer_id',\$request->user()->id)->lockForUpdate()->first()"));
assert(str_contains($customer,'return DB::transaction(function()use($request,$event,$data)'));
assert(str_contains($booking,'if(!$branch)abort(404)'));
assert(str_contains($booking,'if(!$hall)abort(404)'));
echo "V33 tenant scope and ownership checks passed\n";
