<?php
require __DIR__.'/../app/Domain/Accounting/JournalValidator.php';
require __DIR__.'/../app/Domain/Accounting/PosTaxJournalPreview.php';
use App\Domain\Accounting\PosTaxJournalPreview;
$r=PosTaxJournalPreview::build(11500,1500,1,2,3);
assert($r['net_halalas']===10000&&$r['vat_halalas']===1500);
assert(PosTaxJournalPreview::build(100,0,1,2,3)['vat_halalas']===0);
assert(PosTaxJournalPreview::build(1,1500,1,2,3)['gross_halalas']===1);
foreach([[0,1500,1,2,3],[100,-1,1,2,3],[100,1500,1,1,3]] as $args){
 try{PosTaxJournalPreview::build(...$args);throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V24 VAT preview tests passed\n";
