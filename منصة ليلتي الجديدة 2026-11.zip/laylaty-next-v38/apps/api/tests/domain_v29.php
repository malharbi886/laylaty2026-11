<?php
require __DIR__.'/../app/Domain/Stores/StorefrontPolicy.php';
use App\Domain\Stores\StorefrontPolicy;
assert(StorefrontPolicy::slug('  My-Store  ')==='my-store');
assert(StorefrontPolicy::publicStatus('published'));
assert(!StorefrontPolicy::publicStatus('draft'));
StorefrontPolicy::taskStatus('todo','in_progress');
StorefrontPolicy::taskStatus('in_progress','done');
foreach([fn()=>StorefrontPolicy::slug('../admin'),fn()=>StorefrontPolicy::taskStatus('done','todo'),fn()=>StorefrontPolicy::taskStatus('todo','done')] as $fn){
 try{$fn();throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
}
echo "V29 storefront and tasks checks passed\n";
