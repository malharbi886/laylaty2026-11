<?php
require __DIR__.'/../app/Domain/Merchants/OrderWorkflow.php';
use App\Domain\Merchants\OrderWorkflow;
assert(OrderWorkflow::transition('new','confirmed')==='confirmed');
assert(OrderWorkflow::transition('confirmed','in_production')==='in_production');
assert(OrderWorkflow::transition('in_production','ready')==='ready');
assert(OrderWorkflow::transition('ready','delivered')==='delivered');
assert(OrderWorkflow::consumesStock('product'));
assert(!OrderWorkflow::consumesStock('service'));
foreach([['new','delivered'],['delivered','cancelled'],['cancelled','confirmed']] as [$a,$b]){
 try{OrderWorkflow::transition($a,$b);throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V13 order workflow checks passed\n";
