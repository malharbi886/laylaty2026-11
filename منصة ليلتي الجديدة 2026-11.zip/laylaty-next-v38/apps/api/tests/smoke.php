<?php
require __DIR__.'/../app/Domain/Tenancy/TenantContext.php';
require __DIR__.'/../app/Domain/Bookings/BookingPolicy.php';
require __DIR__.'/../app/Domain/Accounting/JournalValidator.php';
use App\Domain\Tenancy\TenantContext;
use App\Domain\Bookings\BookingPolicy;
use App\Domain\Accounting\JournalValidator;
function check(bool $ok, string $message): void { if (!$ok) throw new RuntimeException($message); }
function mustThrow(callable $fn, string $message): void { try {$fn();} catch (DomainException|InvalidArgumentException $e) {return;} throw new RuntimeException($message); }
$a=new TenantContext('tenant-A'); $policy=new BookingPolicy($a);
$a->assertOwns('tenant-A');
mustThrow(fn()=>$a->assertOwns('tenant-B'),'Cross-tenant access permitted');
$booking=['id'=>'b1','tenant_id'=>'tenant-A','hall_id'=>'h1','slot_id'=>'evening','date'=>'2026-12-01','status'=>'pending'];
check($policy->canConfirm($booking,[]),'Free slot should confirm');
check(!$policy->canConfirm($booking,[array_merge($booking,['id'=>'b2','status'=>'confirmed'])]),'Double booking permitted');
mustThrow(fn()=>$policy->canConfirm($booking,[array_merge($booking,['id'=>'b3','tenant_id'=>'tenant-B'])]),'Cross-tenant overlap accepted');
JournalValidator::validate([['debit'=>10000,'credit'=>0],['debit'=>0,'credit'=>10000]]);
mustThrow(fn()=>JournalValidator::validate([['debit'=>10000,'credit'=>0],['debit'=>0,'credit'=>9000]]),'Unbalanced entry accepted');
echo "PASS: tenant, booking-policy, journal smoke tests\n";
