<?php
require __DIR__.'/../app/Domain/Accounting/JournalValidator.php';
require __DIR__.'/../app/Domain/Accounting/PosTaxJournalPreview.php';
use App\Domain\Accounting\PosTaxJournalPreview;
$r=PosTaxJournalPreview::build(115000,1500,1,2,3);
assert($r['net_halalas']===100000);
assert($r['vat_halalas']===15000);
foreach([0,PHP_INT_MAX] as $v){
 try{PosTaxJournalPreview::build($v,1500,1,2,3);throw new RuntimeException('Must reject invalid gross');}
 catch(DomainException $e){}
}
$route=file_get_contents(__DIR__.'/../routes/api.php');
assert(str_contains($route,"Route::post('store/pos/sales/{sale}/tax-journal-preview'"));
assert(!str_contains($route,"Route::post('pos/sales/{sale}/tax-journal-preview'"));
$controller=file_get_contents(__DIR__.'/../app/Http/Controllers/Api/PosTaxPreviewController.php');
assert(str_contains($controller,"$row->status!=='completed'"));
echo "V25 VAT preview safety checks passed\n";
