<?php
require_once __DIR__ . '/../app/Domain/Tenancy/TenantPublicId.php';
use App\Domain\Tenancy\TenantPublicId;
for ($i = 0; $i < 100; $i++) assert(TenantPublicId::isValid(TenantPublicId::generate()));
assert(!TenantPublicId::isValid('000000000000000000000001x'));
assert(!TenantPublicId::isValid('123'));
echo "V34 public ID compatibility checks passed\n";
