<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Domain/Tenancy/TenantPublicId.php';
use App\Domain\Tenancy\TenantPublicId;
for ($i=0;$i<200;$i++) {
    $id=TenantPublicId::generate();
    assert(strlen($id)===7);
    assert(TenantPublicId::isValid($id));
}
foreach (['1234567','AAAAaaa','12345AA','12345aa','12A34b','12345A!'] as $bad) {
    assert(!TenantPublicId::isValid($bad));
}
echo "V37 public-id format checks passed\n";
