<?php
require __DIR__.'/../app/Domain/Tenancy/AccessPolicy.php';
use App\Domain\Tenancy\AccessPolicy;
assert(AccessPolicy::validMembership('owner'));
assert(AccessPolicy::validMembership('accountant'));
assert(!AccessPolicy::validMembership('superadmin'));
assert(!AccessPolicy::validMembership('OWNER'));
assert(!AccessPolicy::validMembership(null));
assert(AccessPolicy::matchesRouteTenant(10,10));
assert(!AccessPolicy::matchesRouteTenant(10,11));
assert(!AccessPolicy::matchesRouteTenant(0,0));
assert(AccessPolicy::belongsToCustomer(23,23));
assert(!AccessPolicy::belongsToCustomer(23,24));
echo "V31 tenancy access checks passed\n";
