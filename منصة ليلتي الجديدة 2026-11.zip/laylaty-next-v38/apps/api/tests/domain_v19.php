<?php
require __DIR__.'/../app/Domain/Inventory/StocktakeApplyPolicy.php';
use App\Domain\Inventory\StocktakeApplyPolicy;
assert(StocktakeApplyPolicy::delta(10,10,7)===-3);
assert(StocktakeApplyPolicy::delta(0,0,5)===5);
foreach([[10,11,5],[-1,-1,0]] as $case){
 try{StocktakeApplyPolicy::delta(...$case);throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V19 stocktake application policy passed\n";
