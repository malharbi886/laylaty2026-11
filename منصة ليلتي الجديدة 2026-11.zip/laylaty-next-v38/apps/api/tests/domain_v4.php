<?php
require __DIR__.'/../app/Domain/Tenancy/TenantGuard.php';
require __DIR__.'/../app/Domain/Bookings/BookingStateMachine.php';
require __DIR__.'/../app/Domain/Accounting/Money.php';
use App\Domain\Tenancy\TenantGuard;
use App\Domain\Bookings\BookingStateMachine;
use App\Domain\Accounting\Money;
function mustThrow(callable $fn):void {try {$fn();}catch(\DomainException|\InvalidArgumentException $e){return;}throw new \RuntimeException('Expected exception');}
TenantGuard::assertSameTenant(1,1);
mustThrow(fn()=>TenantGuard::assertSameTenant(1,2));
assert(BookingStateMachine::transition('pending','confirmed')==='confirmed');
mustThrow(fn()=>BookingStateMachine::transition('cancelled','confirmed'));
assert(Money::remaining(2300000,[500000,250000])===1550000);
mustThrow(fn()=>Money::remaining(100,[101]));
echo "V4 domain checks passed\n";
