<?php
require __DIR__.'/../app/Domain/Billing/InvoiceCalculator.php';
require __DIR__.'/../app/Domain/Subscriptions/SubscriptionPolicy.php';
require __DIR__.'/../app/Domain/POS/ShiftCalculator.php';
require __DIR__.'/../app/Domain/Commissions/HallCommission.php';
require __DIR__.'/../app/Domain/Notifications/IdempotencyKey.php';
use App\Domain\Billing\InvoiceCalculator;
use App\Domain\Subscriptions\SubscriptionPolicy;
use App\Domain\POS\ShiftCalculator;
use App\Domain\Commissions\HallCommission;
use App\Domain\Notifications\IdempotencyKey;
function expectDomainError(callable $f):void{try{$f();throw new RuntimeException('Expected DomainException');}catch(DomainException $e){}}
assert(InvoiceCalculator::calculate([['quantity'=>2,'unit_price_halalas'=>10000]],1500)===['subtotal_halalas'=>20000,'vat_halalas'=>3000,'total_halalas'=>23000]);
expectDomainError(fn()=>InvoiceCalculator::calculate([['quantity'=>0,'unit_price_halalas'=>100]],1500));
assert(SubscriptionPolicy::eligible('hall','advanced_accounting'));
assert(!SubscriptionPolicy::eligible('hall','marketplace'));
assert(SubscriptionPolicy::eligible('store','marketplace'));
assert(SubscriptionPolicy::status('2026-11-05','2026-11-01','2026-11-08')==='grace');
assert(ShiftCalculator::cashDifference(10000,5000,1000,0,14000)===0);
assert(HallCommission::amount(100000,500)===5000);
assert(IdempotencyKey::build('whatsapp','otp','u1','e1')===IdempotencyKey::build('whatsapp','otp','u1','e1'));
assert(IdempotencyKey::build('whatsapp','otp','u1','e1')!==IdempotencyKey::build('sms','otp','u1','e1'));
echo "V9 domain checks passed\n";
