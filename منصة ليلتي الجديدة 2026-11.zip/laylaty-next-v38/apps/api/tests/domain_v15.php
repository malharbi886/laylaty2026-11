<?php
require __DIR__.'/../app/Domain/Inventory/StockMovement.php';
require __DIR__.'/../app/Domain/Inventory/TransferPolicy.php';
use App\Domain\Inventory\TransferPolicy;
assert(TransferPolicy::move(10,5,3)===[7,8]);
foreach([fn()=>TransferPolicy::validate(1,1,3),fn()=>TransferPolicy::validate(1,2,0),
 fn()=>TransferPolicy::move(1,0,2)] as $test){
 try{$test();throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
}
echo "V15 transfer checks passed\n";
