<?php
require __DIR__.'/../app/Domain/Merchants/MerchantPolicy.php';
use App\Domain\Merchants\MerchantPolicy;
MerchantPolicy::requireStore('store');
assert(MerchantPolicy::orderTotal([['quantity'=>2,'unit_price_halalas'=>1500],
 ['quantity'=>1,'unit_price_halalas'=>700]])===3700);
foreach([fn()=>MerchantPolicy::requireStore('hall'),
 fn()=>MerchantPolicy::orderTotal([]),
 fn()=>MerchantPolicy::orderTotal([['quantity'=>0,'unit_price_halalas'=>20]])] as $fn){
 try{$fn();throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
}
echo "V12 merchant checks passed\n";
