<?php
require __DIR__.'/../app/Domain/POS/PartialRefundPolicy.php';
use App\Domain\POS\PartialRefundPolicy;
$sold=[['line_id'=>7,'quantity'=>3,'line_total_halalas'=>100]];
$a=PartialRefundPolicy::calculate($sold,[],[7=>1]);
$b=PartialRefundPolicy::calculate($sold,[7=>1],[7=>1]);
$c=PartialRefundPolicy::calculate($sold,[7=>2],[7=>1]);
assert($a['total_halalas']+$b['total_halalas']+$c['total_halalas']===100);
try{PartialRefundPolicy::calculate($sold,[7=>2],[7=>2]);throw new RuntimeException('Should reject');}
catch(DomainException $e){}
echo "V27 refund quote policy passed\n";
