<?php
require __DIR__.'/../app/Domain/POS/CashRefundPolicy.php';
use App\Domain\POS\CashRefundPolicy;
CashRefundPolicy::authorize('completed','open',1200,0);
assert(CashRefundPolicy::expectedCash(50000,120000,20000)===150000);
foreach([fn()=>CashRefundPolicy::authorize('draft','open',100,0),
 fn()=>CashRefundPolicy::authorize('completed','closed',100,0),
 fn()=>CashRefundPolicy::authorize('completed','open',100,1),
 fn()=>CashRefundPolicy::expectedCash(0,100,101)] as $f){
 try{$f();throw new RuntimeException('Expected DomainException');}catch(DomainException $e){}
}
echo "V22 cash refund domain checks passed\n";
