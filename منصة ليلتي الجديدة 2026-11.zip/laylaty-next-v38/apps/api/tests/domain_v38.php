<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Domain/Audit/AuditDiff.php';
use App\Domain\Audit\AuditDiff;
assert(AuditDiff::between(['status'=>'confirmed','secret'=>'a'],['status'=>'cancelled','secret'=>'b'],['status']) === ['status'=>['before'=>'confirmed','after'=>'cancelled']]);
$workflow=file_get_contents(__DIR__.'/../app/Http/Controllers/Api/MerchantOrderWorkflowController.php');
assert(str_contains($workflow,"'reason'=>'required_if:status,cancelled"));
assert(str_contains($workflow,'AuditRecorder::record('));
assert(!str_contains($workflow,"DB::table('audit_events')->insert("));
echo "V38 cancellation audit contract tests passed\n";
