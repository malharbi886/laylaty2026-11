<?php
declare(strict_types=1);
require_once __DIR__.'/../app/Domain/Audit/AuditDiff.php';
require_once __DIR__.'/../app/Domain/Audit/AuditAccess.php';
use App\Domain\Audit\AuditDiff;
use App\Domain\Audit\AuditAccess;
$changes = AuditDiff::between(['status'=>'new','amount'=>100,'password'=>'old'], ['status'=>'paid','amount'=>100,'password'=>'new'], ['status','amount']);
assert($changes === ['status'=>['before'=>'new','after'=>'paid']]);
assert(AuditDiff::between([],['status'=>'new'],['status']) === []);
assert(AuditAccess::canReadTenantLog('owner'));
foreach (['manager','viewer','accountant','platform_auditor',''] as $role) assert(!AuditAccess::canReadTenantLog($role));
assert(AuditAccess::canReadCentralLog('platform_auditor'));
assert(!AuditAccess::canReadCentralLog('owner'));
echo "V36 audit policy tests passed\n";
