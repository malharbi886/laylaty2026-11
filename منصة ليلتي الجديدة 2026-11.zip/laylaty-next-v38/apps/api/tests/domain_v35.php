<?php
require_once __DIR__ . '/../app/Domain/Tenancy/TenantPublicId.php';
use App\Domain\Tenancy\TenantPublicId;
$ids = [];
for ($i = 0; $i < 5000; $i++) {
    $id = TenantPublicId::generate();
    assert(strlen($id) === 7);
    assert(TenantPublicId::isValid($id));
    assert(!isset($ids[$id]));
    $ids[$id] = true;
}
foreach (['12345Ab', 'a12345B', '12a34B5'] as $valid) assert(TenantPublicId::isValid($valid));
foreach (['123456A','12345AB','12345ab','1234Ab','12345A!','12345Ab0','１２３４５Ab'] as $invalid) assert(!TenantPublicId::isValid($invalid));
echo "V35 seven-character public IDs passed\n";
