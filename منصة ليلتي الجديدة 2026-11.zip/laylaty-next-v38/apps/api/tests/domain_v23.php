<?php
require __DIR__.'/../app/Domain/Accounting/JournalValidator.php';
require __DIR__.'/../app/Domain/Accounting/PosJournalDraft.php';
use App\Domain\Accounting\PosJournalDraft;
assert(PosJournalDraft::lines('sale',15000,1,2)[0]['debit_halalas']===15000);
assert(PosJournalDraft::lines('refund',15000,1,2)[0]['debit_halalas']===15000);
foreach([['sale',0,1,2],['sale',10,1,1],['other',10,1,2]] as $args){
 try{PosJournalDraft::lines(...$args);throw new RuntimeException('Expected rejection');}
 catch(DomainException $e){}
}
echo "V23 accounting draft checks passed\n";
