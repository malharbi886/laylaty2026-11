<?php
require __DIR__.'/../app/Domain/Accounting/JournalValidator.php';
use App\Domain\Accounting\JournalValidator;
JournalValidator::validate([
 ['debit_halalas'=>50000,'credit_halalas'=>0],
 ['debit_halalas'=>0,'credit_halalas'=>50000]
]);
foreach([
 [['debit_halalas'=>50000,'credit_halalas'=>0],['debit_halalas'=>0,'credit_halalas'=>49999]],
 [['debit_halalas'=>50000,'credit_halalas'=>50000],['debit_halalas'=>0,'credit_halalas'=>0]]
] as $bad) {
 try{JournalValidator::validate($bad);throw new RuntimeException('Expected failure');}
 catch(DomainException $e){}
}
echo "V7 journal validation passed\n";
