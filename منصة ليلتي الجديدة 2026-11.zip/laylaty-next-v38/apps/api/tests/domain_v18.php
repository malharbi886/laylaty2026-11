<?php
require __DIR__.'/../app/Domain/Inventory/StocktakePolicy.php';
use App\Domain\Inventory\StocktakePolicy;
assert(StocktakePolicy::variance(12,10)===-2);
assert(StocktakePolicy::variance(10,15)===5);
assert(StocktakePolicy::variance(0,0)===0);
try{StocktakePolicy::variance(-1,3);throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
echo "V18 stocktake policy passed\n";
