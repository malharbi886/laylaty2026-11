<?php
require __DIR__.'/../app/Domain/Merchants/PurchaseMath.php';
require __DIR__.'/../app/Domain/Merchants/AppointmentPolicy.php';
use App\Domain\Merchants\PurchaseMath;
use App\Domain\Merchants\AppointmentPolicy;
assert(PurchaseMath::total([['quantity'=>3,'unit_cost_halalas'=>1250],['quantity'=>1,'unit_cost_halalas'=>250]])===4000);
assert(AppointmentPolicy::overlaps('2026-11-07 10:00:00','2026-11-07 11:00:00','2026-11-07 10:30:00','2026-11-07 11:30:00'));
assert(!AppointmentPolicy::overlaps('2026-11-07 10:00:00','2026-11-07 11:00:00','2026-11-07 11:00:00','2026-11-07 12:00:00'));
foreach([fn()=>PurchaseMath::total([]),fn()=>PurchaseMath::total([['quantity'=>0,'unit_cost_halalas'=>1]]),fn()=>AppointmentPolicy::assertWindow('2026-11-07 12:00:00','2026-11-07 10:00:00')] as $f){
 try{$f();throw new RuntimeException('Should reject');}catch(DomainException $e){}
}
echo "V16 domain checks passed\n";
