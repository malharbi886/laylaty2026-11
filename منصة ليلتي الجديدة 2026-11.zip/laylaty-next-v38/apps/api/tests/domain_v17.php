<?php
require __DIR__.'/../app/Domain/Merchants/ReceiptPolicy.php';
use App\Domain\Merchants\ReceiptPolicy;
ReceiptPolicy::receive('draft');
assert(ReceiptPolicy::nextQuantity(20,3)===23);
foreach([fn()=>ReceiptPolicy::receive('received'),fn()=>ReceiptPolicy::nextQuantity(0,0),fn()=>ReceiptPolicy::nextQuantity(2147483647,1)] as $fn){
 try{$fn();throw new RuntimeException('Expected rejection');}catch(DomainException $e){}
}
echo "V17 receipt policy passed\n";
