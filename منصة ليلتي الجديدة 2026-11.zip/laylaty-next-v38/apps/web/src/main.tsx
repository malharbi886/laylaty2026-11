import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import specialties from './specialties.json';
import './style.css';
type Area='customer'|'merchant'|'halls'|'admin';
const areas:{id:Area;name:string;desc:string}[]=[
{id:'customer',name:'تطبيق العميل',desc:'المناسبات والمهام والميزانية والمتاجر'},
{id:'merchant',name:'لوحة التاجر',desc:'المنتجات والطلبات والكاشير والمحاسبة'},
{id:'halls',name:'إدارة القاعات',desc:'التقويم والعقود والدفعات'},
{id:'admin',name:'الإدارة المركزية',desc:'المنشآت والاشتراكات والعمولات'}];
const modules:Record<Area,string[]>={
customer:['الرئيسية','استكشاف المتاجر','مناسباتي','المهام','ميزانيتي','حجوزاتي وطلباتي','العقود والفواتير','الإشعارات','التقييمات'],
merchant:['الرئيسية','المنتجات والخدمات','الطلبات','الحجوزات','العملاء','الفروع','المخزون والتأجير','الكاشير POS','المحاسبة','الفواتير والدفعات','التقارير','الموظفون والصلاحيات','الإعدادات'],
halls:['الرئيسية','القاعات والفروع','التقويم','الحجوزات','العقود وملحق الخدمات','الدفعات والفواتير','العملاء','الصور و360°','التقارير','المحاسبة (اشتراك)','الموظفون والصلاحيات','الإعدادات'],
admin:['الرئيسية','المنشآت والمتاجر','التخصصات','العملاء','الاشتراكات','عمولات القاعات','الطلبات والحجوزات','الفواتير والمدفوعات','المحتوى','التقييمات والشكاوى','الإشعارات','التقارير','الأدوار والصلاحيات','الإعدادات']};
function App(){
const [area,setArea]=useState<Area>('admin');
const [module,setModule]=useState('الرئيسية');
const [search,setSearch]=useState('');
const [selected,setSelected]=useState('halls');
const [booking,setBooking]=useState('LY-H-DEMO-001');
const chosen=specialties.find(s=>s.id===selected)!;
const switchArea=(a:Area)=>{setArea(a);setModule('الرئيسية')};
return <div className="shell" dir="rtl">
<header><div className="brand"><span className="mark">✦</span><div><b>ليلتي</b><small>MY NIGHT · منصة الإدارة</small></div></div><span className="tag">نموذج واجهات تجريبي — لا بيانات حقيقية</span></header>
<div className="layout"><aside><h3>مساحات العمل</h3>{areas.map(a=><button className={area===a.id?'active':''} onClick={()=>switchArea(a.id)} key={a.id}>{a.name}</button>)}<h3>أقسام {areas.find(a=>a.id===area)?.name}</h3>{modules[area].map(m=><button key={m} className={module===m?'active sub':'sub'} onClick={()=>setModule(m)}>{m}</button>)}</aside>
<main><div className="hero"><div><p className="eyebrow">LAYLATY NEXT / {areas.find(a=>a.id===area)?.name}</p><h1>{module}</h1><p>{areas.find(a=>a.id===area)?.desc}</p></div><div className="hero-icon">✧</div></div>
{module==='الرئيسية'&&<div className="stats">{['التخصصات: 16','مساحات العمل: 4','عزل المنشآت: مطلوب','الوضع: تجريبي'].map(x=><div className="stat" key={x}>{x}</div>)}</div>}
<section className="panel"><div className="panel-heading"><div><h2>دليل التخصصات والمتاجر</h2><p>جميع الأقسام الستة عشر، ووظائف الكاشير والحجوزات حسب النشاط.</p></div><input placeholder="ابحث عن تخصص..." value={search} onChange={e=>setSearch(e.target.value)}/></div>
<div className="cards">{specialties.filter(s=>s.name.includes(search)||s.description.includes(search)).map((s,i)=><button key={s.id} onClick={()=>setSelected(s.id)} className={'specialty '+(selected===s.id?'chosen':'')}><span className="num">{String(i+1).padStart(2,'0')}</span><strong>{s.name}</strong><span>{s.description}</span><div className="chips"><em>{s.pos?'POS':'بدون POS'}</em><em>{s.booking?'حجوزات':'طلبات'}</em></div></button>)}</div></section>
<section className="panel"><h2>التخصص المحدد: {chosen.name}</h2><p>{chosen.description}</p><div className="detail-grid"><div><b>المكونات الأساسية</b><p>المنشأة، الفروع، العملاء، الصلاحيات، الفواتير، الدفعات، التقارير.</p></div><div><b>الكاشير</b><p>{chosen.pos?'متاح حسب خطة المتجر وصلاحياته.':'غير مفعل لهذا النشاط.'}</p></div><div><b>المواعيد والحجوزات</b><p>{chosen.booking?'محرك حجز قابل للتخصيص.':'إدارة الطلبات ومواعيد التسليم.'}</p></div><div><b>المحاسبة</b><p>قيود مزدوجة وضرائب وقوائم مالية ضمن نطاق التنفيذ المرحلي.</p></div></div></section>
<section className="panel"><h2>مرجع الحجز الموحد — معاينة</h2><p>الضغط على الرقم من أي قسم يجب أن يفتح صفحة الحجز وفق صلاحيات المستخدم.</p><div className="booking"><input aria-label="رقم الحجز" value={booking} onChange={e=>setBooking(e.target.value)}/><button onClick={()=>alert('واجهة توضيحية فقط: يلزم API ومصادقة وصلاحيات لفتح الحجز '+booking)}>عرض تفاصيل الحجز</button></div></section>
<footer>هذا الإصدار واجهة تأسيسية قابلة للتشغيل محليًا، وليس نظامًا إنتاجيًا أو محاسبة مكتملة.</footer>
</main></div></div>}
createRoot(document.getElementById('root')!).render(<App/>);
